import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { CreditCard, Shield, AlertCircle, ArrowLeft } from 'lucide-react';
import { createPayment } from '../../services/paparaService';
import type { PaymentPackage } from '../../types/payment';
import { useCredits } from '../../context/CreditContext';

export default function PaymentPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { addCredits } = useCredits();
  const [selectedPackage, setSelectedPackage] = useState<PaymentPackage | null>(null);
  const [tcNo, setTcNo] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const pkg = location.state?.package;
    if (!pkg) {
      navigate('/credits');
      return;
    }
    setSelectedPackage(pkg);
  }, [location.state, navigate]);

  const handlePayment = async () => {
    if (!selectedPackage) {
      setError('Paket seçimi bulunamadı');
      return;
    }

    if (!tcNo || tcNo.length !== 11) {
      setError('Geçerli bir TC Kimlik Numarası girin');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const response = await createPayment({
        amount: selectedPackage.price,
        referenceId: `order_${Date.now()}`,
        description: `${selectedPackage.credits} Kredi Yükleme`,
        turkishNationalId: tcNo
      });

      if (response.success && response.paymentPageUrl) {
        window.location.href = response.paymentPageUrl;
      } else {
        throw new Error(response.error || 'Ödeme işlemi başlatılamadı');
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Ödeme işlemi başlatılamadı');
    } finally {
      setIsLoading(false);
    }
  };

  if (!selectedPackage) {
    return null;
  }

  return (
    <div className="max-w-2xl mx-auto p-6">
      <button
        onClick={() => navigate('/credits')}
        className="flex items-center text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Paket Seçimine Dön
      </button>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Ödeme Bilgileri</h2>

        <div className="mb-6 p-4 bg-gray-50 rounded-lg">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-medium text-gray-900">{selectedPackage.name}</h3>
              <p className="text-sm text-gray-600">{selectedPackage.credits} Kredi</p>
            </div>
            <span className="text-xl font-bold text-gray-900">{selectedPackage.price} TL</span>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center text-red-600">
            <AlertCircle className="w-5 h-5 mr-2" />
            {error}
          </div>
        )}

        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            TC Kimlik Numarası
          </label>
          <input
            type="text"
            maxLength={11}
            value={tcNo}
            onChange={(e) => setTcNo(e.target.value.replace(/\D/g, ''))}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="TC Kimlik Numaranızı girin"
          />
        </div>

        <div className="bg-blue-50 p-4 rounded-lg mb-6">
          <div className="flex items-start">
            <Shield className="w-5 h-5 text-blue-600 mt-0.5 mr-2" />
            <div className="text-sm text-blue-700">
              <p className="font-medium mb-1">Güvenli Ödeme</p>
              <p>Papara altyapısı ile güvenli ödeme yapabilirsiniz. Kredi kartı bilgileriniz bizimle paylaşılmaz.</p>
            </div>
          </div>
        </div>

        <button
          onClick={handlePayment}
          disabled={isLoading}
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 flex items-center justify-center space-x-2 disabled:opacity-50"
        >
          <CreditCard className="w-5 h-5" />
          <span>{isLoading ? 'İşleminiz Yapılıyor...' : 'Papara ile Öde'}</span>
        </button>
      </div>
    </div>
  );
}