import React from 'react';
import { ClipboardCheck, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function DoctorPending() {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Eğer kullanıcı yoksa veya doktor değilse ana sayfaya yönlendir
  if (!user || user.role !== 'doctor') {
    navigate('/');
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
        <div className="text-center">
          <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-blue-100">
            <ClipboardCheck className="h-6 w-6 text-blue-600" />
          </div>
          <h2 className="mt-6 text-3xl font-extrabold text-gray-900">
            Başvurunuz Alındı
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Üyelik başvurunuz inceleme aşamasındadır. Başvurunuz onaylandığında
            e-posta ile bilgilendirileceksiniz.
          </p>
        </div>

        <div className="mt-8">
          <div className="rounded-md bg-blue-50 p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <AlertCircle className="h-5 w-5 text-blue-400" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-blue-800">
                  Başvuru Süreci
                </h3>
                <div className="mt-2 text-sm text-blue-700">
                  <ul className="list-disc pl-5 space-y-1">
                    <li>
                      Başvurunuz 24-48 saat içinde değerlendirilecektir.
                    </li>
                    <li>
                      Belgelerinizde eksiklik tespit edilirse bilgilendirileceksiniz.
                    </li>
                    <li>
                      Başvurunuz onaylandığında sisteme giriş yapabileceksiniz.
                    </li>
                    <li>
                      Onay sürecinde sorularınız için destek ekibimizle iletişime geçebilirsiniz.
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8">
          <button
            onClick={() => navigate('/')}
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Ana Sayfaya Dön
          </button>
        </div>
      </div>
    </div>
  );
}