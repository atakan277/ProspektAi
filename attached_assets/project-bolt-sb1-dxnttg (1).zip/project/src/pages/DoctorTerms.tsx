import React from 'react';

export default function DoctorTerms() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="bg-white rounded-lg shadow-lg p-8">
        <h1 className="text-3xl font-bold mb-6">Doktor Üyelik Sözleşmesi</h1>
        
        <div className="prose max-w-none">
          <h2 className="text-xl font-semibold mt-8 mb-4">1. Genel Hükümler</h2>
          <p>
            İşbu sözleşme, OnlineSağlık platformunda hizmet verecek hekimlerin hak, yükümlülük ve sorumluluklarını 
            düzenlemektedir. Platform üzerinden verilen hizmetler, 1219 sayılı Tababet ve Şuabatı San'atlarının 
            Tarzı İcrasına Dair Kanun ve ilgili mevzuat hükümlerine tabidir.
          </p>

          <h2 className="text-xl font-semibold mt-8 mb-4">2. Beyan ve Taahhütler</h2>
          <p>
            Hekim, aşağıdaki hususları açıkça beyan ve taahhüt eder:
          </p>
          <ul className="list-disc pl-5 space-y-2">
            <li>
              Sunduğu tüm bilgi ve belgelerin doğru, güncel ve kendisine ait olduğunu,
            </li>
            <li>
              Mesleki yeterlilik ve uzmanlık belgelerinin geçerli olduğunu,
            </li>
            <li>
              Meslekten men edilmediğini ve herhangi bir disiplin cezası bulunmadığını,
            </li>
            <li>
              Platform üzerinden sunacağı hizmetlerde mesleki özen ve dikkati göstereceğini,
            </li>
            <li>
              Hasta mahremiyeti ve kişisel verilerin korunması konusunda gerekli tedbirleri alacağını,
            </li>
            <li>
              Tıbbi deontoloji ve etik kurallara uygun davranacağını.
            </li>
          </ul>

          <h2 className="text-xl font-semibold mt-8 mb-4">3. Sorumluluk ve Yükümlülükler</h2>
          <p>
            Hekim, platform üzerinden verdiği tüm hizmetlerde:
          </p>
          <ul className="list-disc pl-5 space-y-2">
            <li>
              Tıbbi görüş ve önerilerinin kendi mesleki kanaati olduğunu ve bunlardan tamamen kendisinin sorumlu olduğunu,
            </li>
            <li>
              Platform üzerinden yapılan görüşmelerin yüz yüze muayenenin yerini tutmayacağını hastalarına açıkça bildireceğini,
            </li>
            <li>
              Acil durumlarda hastaları en yakın sağlık kuruluşuna yönlendireceğini,
            </li>
            <li>
              Reçete düzenleme ve ilaç önerilerinde ilgili mevzuata uygun davranacağını,
            </li>
            <li>
              Hasta kayıtlarını güvenli şekilde saklayacağını ve üçüncü kişilerle paylaşmayacağını
            </li>
          </ul>

          <h2 className="text-xl font-semibold mt-8 mb-4">4. Mesleki Sorumluluk Sigortası</h2>
          <p>
            Hekim, mesleki sorumluluk sigortasının geçerli olduğunu ve platform üzerinden verdiği hizmetleri 
            kapsadığını taahhüt eder. Sigorta poliçesinin süresi dolduğunda yenilenmiş poliçeyi platforma ibraz 
            etmekle yükümlüdür.
          </p>

          <h2 className="text-xl font-semibold mt-8 mb-4">5. Hukuki ve Cezai Sorumluluk</h2>
          <p>
            Hekim, platform üzerinden verdiği hizmetler nedeniyle ortaya çıkabilecek her türlü hukuki ve cezai 
            sorumluluğun kendisine ait olduğunu kabul eder. Platform işletmecisi, hekimin verdiği hizmetlerden 
            dolayı üçüncü kişilere karşı sorumlu tutulamaz.
          </p>

          <h2 className="text-xl font-semibold mt-8 mb-4">6. Sözleşmenin Feshi</h2>
          <p>
            Platform işletmecisi, hekimin beyan ve taahhütlerine aykırı davranması, mesleki özen ve dikkat 
            yükümlülüğünü ihlal etmesi veya hasta şikayetlerinin artması durumunda sözleşmeyi tek taraflı 
            olarak feshedebilir.
          </p>

          <div className="bg-yellow-50 p-4 rounded-lg mt-8">
            <p className="text-sm text-yellow-800">
              Bu sözleşmeyi kabul ederek, yukarıda belirtilen tüm hükümleri okuduğunuzu, anladığınızı ve 
              kabul ettiğinizi beyan etmektesiniz. Verdiğiniz bilgilerin doğruluğundan ve güncelliğinden 
              tamamen siz sorumlusunuz.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}