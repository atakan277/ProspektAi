import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Save, Bell, Shield } from 'lucide-react';

export default function DoctorSettings() {
  const { user } = useAuth();
  const [settings, setSettings] = useState({
    notifications: {
      email: true,
      sms: true,
      app: true
    },
    privacy: {
      showPhone: true,
      showEmail: true,
      allowMessages: true
    },
    availability: {
      monday: true,
      tuesday: true,
      wednesday: true,
      thursday: true,
      friday: true,
      saturday: false,
      sunday: false
    }
  });

  const handleSave = () => {
    // API call will be implemented here
    alert('Ayarlar kaydedildi');
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-2xl font-bold text-gray-900">Ayarlar</h2>
      </div>

      <div className="p-6 space-y-8">
        {/* Bildirim Ayarları */}
        <section>
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            <Bell className="inline-block w-5 h-5 mr-2" />
            Bildirim Ayarları
          </h3>
          <div className="space-y-4">
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={settings.notifications.email}
                onChange={(e) => setSettings({
                  ...settings,
                  notifications: {
                    ...settings.notifications,
                    email: e.target.checked
                  }
                })}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label className="ml-2 block text-sm text-gray-700">
                E-posta Bildirimleri
              </label>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={settings.notifications.sms}
                onChange={(e) => setSettings({
                  ...settings,
                  notifications: {
                    ...settings.notifications,
                    sms: e.target.checked
                  }
                })}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label className="ml-2 block text-sm text-gray-700">
                SMS Bildirimleri
              </label>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={settings.notifications.app}
                onChange={(e) => setSettings({
                  ...settings,
                  notifications: {
                    ...settings.notifications,
                    app: e.target.checked
                  }
                })}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label className="ml-2 block text-sm text-gray-700">
                Uygulama Bildirimleri
              </label>
            </div>
          </div>
        </section>

        {/* Gizlilik Ayarları */}
        <section>
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            <Shield className="inline-block w-5 h-5 mr-2" />
            Gizlilik Ayarları
          </h3>
          <div className="space-y-4">
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={settings.privacy.showPhone}
                onChange={(e) => setSettings({
                  ...settings,
                  privacy: {
                    ...settings.privacy,
                    showPhone: e.target.checked
                  }
                })}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label className="ml-2 block text-sm text-gray-700">
                Telefon numaramı göster
              </label>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={settings.privacy.showEmail}
                onChange={(e) => setSettings({
                  ...settings,
                  privacy: {
                    ...settings.privacy,
                    showEmail: e.target.checked
                  }
                })}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label className="ml-2 block text-sm text-gray-700">
                E-posta adresimi göster
              </label>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={settings.privacy.allowMessages}
                onChange={(e) => setSettings({
                  ...settings,
                  privacy: {
                    ...settings.privacy,
                    allowMessages: e.target.checked
                  }
                })}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label className="ml-2 block text-sm text-gray-700">
                Mesajlaşmaya izin ver
              </label>
            </div>
          </div>
        </section>

        {/* Çalışma Günleri */}
        <section>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Çalışma Günleri</h3>
          <div className="grid grid-cols-7 gap-4">
            {Object.entries(settings.availability).map(([day, enabled]) => (
              <div key={day} className="flex flex-col items-center">
                <label className="text-sm font-medium text-gray-700 mb-2">
                  {day.charAt(0).toUpperCase() + day.slice(1)}
                </label>
                <input
                  type="checkbox"
                  checked={enabled}
                  onChange={(e) => setSettings({
                    ...settings,
                    availability: {
                      ...settings.availability,
                      [day]: e.target.checked
                    }
                  })}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Save Button */}
      <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
        <button
          onClick={handleSave}
          className="w-full flex justify-center items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Save className="w-4 h-4 mr-2" />
          Ayarları Kaydet
        </button>
      </div>
    </div>
  );
}