import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { useCredits } from '../../context/CreditContext';
import { Search, User } from 'lucide-react';
import MessageBox from '../../components/MessageBox';
import type { Message } from '../../types/message';

const MESSAGE_COST = 5;
const DOCTOR_COMMISSION = 0.6; // 60% goes to doctor, 40% to platform

interface Conversation {
  userId: string;
  userName: string;
  lastMessage: Message;
  unreadCount: number;
}

export default function DoctorMessages() {
  const { user } = useAuth();
  const { messages, users, addMessage, getMessagesForUser } = useData();
  const { transferCredits } = useCredits();
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [newMessage, setNewMessage] = useState('');

  const doctorMessages = user ? getMessagesForUser(user.id) : [];

  // Group messages by conversation
  const conversations: Conversation[] = doctorMessages.reduce((acc: Conversation[], message) => {
    const otherUserId = message.senderId === user?.id ? message.receiverId : message.senderId;
    const existingConv = acc.find(conv => conv.userId === otherUserId);
    const otherUser = users.find(u => u.id === otherUserId);

    if (!otherUser) return acc;

    if (existingConv) {
      if (new Date(message.timestamp) > new Date(existingConv.lastMessage.timestamp)) {
        existingConv.lastMessage = message;
      }
      if (!message.read && message.senderId === otherUserId) {
        existingConv.unreadCount++;
      }
    } else {
      acc.push({
        userId: otherUserId,
        userName: otherUser.name,
        lastMessage: message,
        unreadCount: !message.read && message.senderId === otherUserId ? 1 : 0
      });
    }
    return acc;
  }, []);

  const filteredConversations = conversations.filter(conv =>
    conv.userName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedUserMessages = selectedUserId ? 
    doctorMessages.filter(msg => 
      msg.senderId === selectedUserId || msg.receiverId === selectedUserId
    ).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()) : [];

  const handleSendMessage = () => {
    if (!user || !selectedUserId || !newMessage.trim()) return;

    // When doctor replies, they receive commission from the patient's message cost
    transferCredits(
      selectedUserId, // from patient
      user.id, // to doctor
      MESSAGE_COST,
      1 - DOCTOR_COMMISSION // platform keeps 40%
    );

    const message: Message = {
      id: Date.now().toString(),
      senderId: user.id,
      receiverId: selectedUserId,
      content: newMessage,
      timestamp: new Date(),
      read: false,
      credited: true
    };

    addMessage(message);
    setNewMessage('');
  };

  // Mark messages as read when conversation is selected
  useEffect(() => {
    if (selectedUserId && user) {
      const unreadMessages = selectedUserMessages.filter(
        msg => !msg.read && msg.senderId === selectedUserId
      );

      if (unreadMessages.length > 0) {
        unreadMessages.forEach(msg => {
          addMessage({ ...msg, read: true });
        });
      }
    }
  }, [selectedUserId, selectedUserMessages]);

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden h-[800px] flex">
      {/* Conversations List */}
      <div className="w-1/3 border-r border-gray-200">
        <div className="p-4 border-b border-gray-200">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Hasta ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <div className="overflow-y-auto h-[calc(800px-73px)]">
          {filteredConversations.map((conv) => (
            <button
              key={conv.userId}
              onClick={() => setSelectedUserId(conv.userId)}
              className={`w-full p-4 hover:bg-gray-50 flex items-start space-x-3 ${
                selectedUserId === conv.userId ? 'bg-blue-50' : ''
              }`}
            >
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-gray-500" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {conv.userName}
                  </p>
                  {conv.lastMessage?.timestamp && (
                    <span className="text-xs text-gray-500">
                      {new Date(conv.lastMessage.timestamp).toLocaleTimeString()}
                    </span>
                  )}
                </div>
                {conv.lastMessage?.content && (
                  <p className="text-sm text-gray-500 truncate">
                    {conv.lastMessage.content}
                  </p>
                )}
              </div>
              {conv.unreadCount > 0 && (
                <span className="inline-flex items-center justify-center w-5 h-5 text-xs font-medium text-white bg-blue-600 rounded-full">
                  {conv.unreadCount}
                </span>
              )}
            </button>
          ))}

          {filteredConversations.length === 0 && (
            <div className="p-4 text-center text-gray-500">
              Mesaj bulunamadı
            </div>
          )}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {selectedUserId ? (
          <>
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-gray-500" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    {users.find(u => u.id === selectedUserId)?.name}
                  </h3>
                  <p className="text-sm text-gray-500">Hasta</p>
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {selectedUserMessages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${
                    message.senderId === user?.id ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div
                    className={`max-w-[70%] rounded-lg p-3 ${
                      message.senderId === user?.id
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100'
                    }`}
                  >
                    <p>{message.content}</p>
                    <div className="flex items-center justify-between mt-1 text-xs opacity-70">
                      <span>{new Date(message.timestamp).toLocaleTimeString()}</span>
                      {message.credited && (
                        <span className="ml-2">
                          {message.senderId === user?.id 
                            ? `+${Math.floor(MESSAGE_COST * DOCTOR_COMMISSION)} Kredi` 
                            : ''}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <MessageBox
              value={newMessage}
              onChange={setNewMessage}
              onSend={handleSendMessage}
            />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-500">
            <p>Mesajlaşmak için bir hasta seçin</p>
          </div>
        )}
      </div>
    </div>
  );
}