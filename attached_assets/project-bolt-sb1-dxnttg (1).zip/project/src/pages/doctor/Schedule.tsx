import React, { useState } from 'react';
import { Calendar, Clock, Plus, Trash2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface TimeSlot {
  id: string;
  date: string;
  time: string;
  isBooked: boolean;
}

export default function DoctorSchedule() {
  const { user } = useAuth();
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTimes, setSelectedTimes] = useState<string[]>([]);
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([]);

  // Generate available time slots (30-minute intervals from 09:00 to 17:00)
  const availableTimes = Array.from({ length: 17 }, (_, i) => {
    const hour = Math.floor(i / 2) + 9;
    const minute = (i % 2) * 30;
    return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
  });

  const handleAddSlots = () => {
    if (!selectedDate || selectedTimes.length === 0) return;

    const newSlots = selectedTimes.map(time => ({
      id: `slot_${Date.now()}_${time}`,
      date: selectedDate,
      time,
      isBooked: false
    }));

    setTimeSlots(prev => [...prev, ...newSlots]);
    setSelectedTimes([]);
  };

  const handleDeleteSlot = (slotId: string) => {
    setTimeSlots(prev => prev.filter(slot => slot.id !== slotId));
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Çalışma Saatleri</h2>

      {/* Add New Slots Form */}
      <div className="bg-gray-50 p-4 rounded-lg mb-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Yeni Zaman Dilimi Ekle</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tarih</label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              min={new Date().toISOString().split('T')[0]}
              className="w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Saatler</label>
            <div className="grid grid-cols-4 gap-2 max-h-40 overflow-y-auto">
              {availableTimes.map((time) => (
                <label key={time} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={selectedTimes.includes(time)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedTimes([...selectedTimes, time]);
                      } else {
                        setSelectedTimes(selectedTimes.filter(t => t !== time));
                      }
                    }}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-sm">{time}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
        <button
          onClick={handleAddSlots}
          disabled={!selectedDate || selectedTimes.length === 0}
          className="mt-4 flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Plus className="w-4 h-4 mr-2" />
          Ekle
        </button>
      </div>

      {/* Existing Slots List */}
      <div className="space-y-4">
        {timeSlots
          .sort((a, b) => new Date(a.date + 'T' + a.time).getTime() - new Date(b.date + 'T' + b.time).getTime())
          .map((slot) => (
            <div key={slot.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-6">
                <div className="flex items-center">
                  <Calendar className="w-5 h-5 text-gray-400 mr-2" />
                  <span className="font-medium">
                    {new Date(slot.date).toLocaleDateString('tr-TR')}
                  </span>
                </div>
                <div className="flex items-center">
                  <Clock className="w-5 h-5 text-gray-400 mr-2" />
                  <span>{slot.time}</span>
                </div>
                {slot.isBooked && (
                  <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                    Rezerve Edildi
                  </span>
                )}
              </div>
              {!slot.isBooked && (
                <button
                  onClick={() => handleDeleteSlot(slot.id)}
                  className="text-red-600 hover:text-red-800"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              )}
            </div>
          ))}

        {timeSlots.length === 0 && (
          <div className="text-center text-gray-500 py-8">
            Henüz çalışma saati eklenmemiş
          </div>
        )}
      </div>
    </div>
  );
}