import React, { useState } from 'react';
import { Search, User, FileText, MessageSquare, Video } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function DoctorPatients() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');

  const patients = [
    {
      id: 'p1',
      name: 'Ahmet Yılmaz',
      lastVisit: '2024-03-10',
      condition: 'Hipertansiyon',
      status: 'Aktif'
    },
    {
      id: 'p2',
      name: 'Ayşe Kaya',
      lastVisit: '2024-03-08',
      condition: 'Diyabet',
      status: 'Takip'
    }
  ];

  const filteredPatients = patients.filter(patient =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">Hastalarım</h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Hasta ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      <div className="divide-y divide-gray-200">
        {filteredPatients.map((patient) => (
          <div key={patient.id} className="p-6 hover:bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-gray-500" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-900">{patient.name}</h3>
                  <div className="mt-1 flex items-center space-x-4">
                    <span className="text-sm text-gray-500">
                      Son Ziyaret: {new Date(patient.lastVisit).toLocaleDateString()}
                    </span>
                    <span className="text-sm text-gray-500">
                      Durum: {patient.condition}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={() => navigate(`/doctor/records/${patient.id}`)}
                  className="p-2 text-gray-400 hover:text-gray-600"
                  title="Kayıtlar"
                >
                  <FileText className="w-5 h-5" />
                </button>
                <button
                  onClick={() => navigate(`/doctor/messages/${patient.id}`)}
                  className="p-2 text-gray-400 hover:text-gray-600"
                  title="Mesaj Gönder"
                >
                  <MessageSquare className="w-5 h-5" />
                </button>
                <button
                  onClick={() => navigate(`/doctor/video-call/${patient.id}`)}
                  className="p-2 text-gray-400 hover:text-gray-600"
                  title="Görüntülü Görüşme"
                >
                  <Video className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        ))}

        {filteredPatients.length === 0 && (
          <div className="p-6 text-center text-gray-500">
            Hasta bulunamadı.
          </div>
        )}
      </div>
    </div>
  );
}