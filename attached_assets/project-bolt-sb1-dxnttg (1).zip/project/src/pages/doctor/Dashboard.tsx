import React from 'react';
import { Calendar, Users, Clock, Activity } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export default function DoctorDashboard() {
  const { user } = useAuth();

  const stats = [
    {
      icon: Users,
      title: 'Toplam Hasta',
      value: '248',
      change: '+12% geçen ay'
    },
    {
      icon: Calendar,
      title: 'Bu Ayki Görüşmeler',
      value: '45',
      change: '+8% geçen ay'
    },
    {
      icon: Clock,
      title: 'Ortalama Görüşme',
      value: '18 dk',
      change: '-2 dk geçen ay'
    }
  ];

  const appointments = [
    {
      id: 1,
      patient: 'Ayşe Yılmaz',
      time: '09:00',
      type: 'Video Görüşme',
      status: 'Bekliyor'
    },
    {
      id: 2,
      patient: 'Mehmet Demir',
      time: '10:30',
      type: 'Mesajlaşma',
      status: 'Onaylandı'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, index) => (
          <StatCard
            key={index}
            icon={stat.icon}
            title={stat.title}
            value={stat.value}
            change={stat.change}
          />
        ))}
      </div>

      {/* Appointments List */}
      <div className="bg-white rounded-lg shadow">
        <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
          <h3 className="text-lg font-medium text-gray-900">Günün Randevuları</h3>
        </div>
        <ul className="divide-y divide-gray-200">
          {appointments.map((appointment) => (
            <li key={appointment.id} className="px-4 py-4 sm:px-6 hover:bg-gray-50">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-600">{appointment.patient}</p>
                  <p className="text-sm text-gray-500">{appointment.type}</p>
                </div>
                <div className="flex items-center">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    {appointment.status}
                  </span>
                  <span className="ml-4 text-sm text-gray-500">{appointment.time}</span>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

const StatCard = ({ 
  icon: Icon, 
  title, 
  value, 
  change 
}: { 
  icon: React.ElementType;
  title: string;
  value: string;
  change: string;
}) => (
  <div className="bg-white rounded-lg shadow p-6">
    <div className="flex items-center">
      <div className="p-3 rounded-full bg-blue-100 text-blue-600">
        <Icon className="h-6 w-6" />
      </div>
      <div className="ml-4">
        <p className="text-sm font-medium text-gray-500">{title}</p>
        <p className="text-2xl font-semibold text-gray-900">{value}</p>
        <p className="text-sm text-gray-500">{change}</p>
      </div>
    </div>
  </div>
);