import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useCredits } from '../context/CreditContext';
import { MessageSquare, Search, User, Send } from 'lucide-react';
import MessageBox from '../components/MessageBox';

interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: Date;
  read: boolean;
  credited: boolean;
}

interface Conversation {
  id: string;
  patientId: string;
  patientName: string;
  lastMessage: string;
  lastMessageTime: Date;
  unreadCount: number;
  messages: Message[];
}

export default function DoctorMessages() {
  const { user } = useAuth();
  const { transferCredits } = useCredits();
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    const saved = localStorage.getItem(`doctor_conversations_${user?.id}`);
    return saved ? JSON.parse(saved) : [];
  });
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (user?.id) {
      localStorage.setItem(`doctor_conversations_${user.id}`, JSON.stringify(conversations));
    }
  }, [conversations, user?.id]);

  const handleSendMessage = (content: string) => {
    if (!selectedConversation || !user) return;

    // Kredi transferi
    const success = transferCredits(
      selectedConversation.patientId, // Hastadan
      user.id, // Doktora
      5 // Toplam kredi (3 doktora, 2 platform komisyonu)
    );

    if (!success) {
      alert('Hastanın yeterli kredisi bulunmuyor.');
      return;
    }

    const newMessage: Message = {
      id: Date.now().toString(),
      senderId: user.id,
      receiverId: selectedConversation.patientId,
      content,
      timestamp: new Date(),
      read: false,
      credited: true
    };

    setConversations(prev => prev.map(conv => {
      if (conv.id === selectedConversation.id) {
        return {
          ...conv,
          lastMessage: content,
          lastMessageTime: new Date(),
          messages: [...conv.messages, newMessage]
        };
      }
      return conv;
    }));
  };

  const filteredConversations = conversations.filter(conv =>
    conv.patientName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden h-[800px] flex">
      {/* Conversations List */}
      <div className="w-1/3 border-r border-gray-200">
        <div className="p-4 border-b border-gray-200">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Hasta ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <div className="overflow-y-auto h-[calc(800px-73px)]">
          {filteredConversations.map((conv) => (
            <button
              key={conv.id}
              onClick={() => setSelectedConversation(conv)}
              className={`w-full p-4 hover:bg-gray-50 flex items-start space-x-3 ${
                selectedConversation?.id === conv.id ? 'bg-blue-50' : ''
              }`}
            >
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-gray-500" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {conv.patientName}
                  </p>
                  <span className="text-xs text-gray-500">
                    {new Date(conv.lastMessageTime).toLocaleTimeString()}
                  </span>
                </div>
                <p className="text-sm text-gray-500 truncate">{conv.lastMessage}</p>
              </div>
              {conv.unreadCount > 0 && (
                <span className="inline-flex items-center justify-center w-5 h-5 text-xs font-medium text-white bg-blue-600 rounded-full">
                  {conv.unreadCount}
                </span>
              )}
            </button>
          ))}

          {filteredConversations.length === 0 && (
            <div className="p-4 text-center text-gray-500">
              Mesaj bulunamadı
            </div>
          )}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {selectedConversation ? (
          <>
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-gray-500" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    {selectedConversation.patientName}
                  </h3>
                  <p className="text-sm text-gray-500">Hasta</p>
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {selectedConversation.messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${
                    message.senderId === user?.id ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div
                    className={`max-w-[70%] rounded-lg p-3 ${
                      message.senderId === user?.id
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100'
                    }`}
                  >
                    <p>{message.content}</p>
                    <div className="flex items-center justify-between mt-1 text-xs opacity-70">
                      <span>
                        {new Date(message.timestamp).toLocaleTimeString()}
                      </span>
                      {message.credited && (
                        <span className="ml-2">
                          {message.senderId === user?.id ? '+3 Kredi' : '-5 Kredi'}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <MessageBox onSend={handleSendMessage} />
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-500">
            <div className="text-center">
              <MessageSquare className="w-12 h-12 mx-auto mb-4" />
              <p>Mesajlaşmak için bir hasta seçin</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}