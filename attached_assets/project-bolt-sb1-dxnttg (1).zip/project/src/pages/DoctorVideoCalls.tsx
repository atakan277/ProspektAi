import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Video, User, Calendar, Clock } from 'lucide-react';

interface VideoCall {
  id: string;
  patientId: string;
  patientName: string;
  date: string;
  time: string;
  status: 'scheduled' | 'in-progress' | 'completed' | 'cancelled';
  duration?: number;
}

const mockCalls: VideoCall[] = [
  {
    id: 'v1',
    patientId: 'p1',
    patientName: 'Ahmet Yılmaz',
    date: '2024-03-15',
    time: '14:30',
    status: 'scheduled'
  },
  {
    id: 'v2',
    patientId: 'p2',
    patientName: 'Ayşe Kaya',
    date: '2024-03-15',
    time: '15:00',
    status: 'scheduled'
  }
];

export default function DoctorVideoCalls() {
  const { user } = useAuth();
  const [calls, setCalls] = useState(mockCalls);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled':
        return 'bg-blue-100 text-blue-800';
      case 'in-progress':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'scheduled':
        return 'Planlandı';
      case 'in-progress':
        return 'Devam Ediyor';
      case 'completed':
        return 'Tamamlandı';
      case 'cancelled':
        return 'İptal Edildi';
      default:
        return status;
    }
  };

  const handleJoinCall = (callId: string) => {
    // Video call logic will be implemented here
    window.location.href = `/video-call/${callId}`;
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">Görüntülü Görüşmeler</h2>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      <div className="divide-y divide-gray-200">
        {calls.map((call) => (
          <div key={call.id} className="p-6 hover:bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-gray-500" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    {call.patientName}
                  </h3>
                  <div className="flex items-center space-x-4 mt-1">
                    <div className="flex items-center text-gray-500">
                      <Calendar className="w-4 h-4 mr-1" />
                      <span className="text-sm">
                        {new Date(call.date).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex items-center text-gray-500">
                      <Clock className="w-4 h-4 mr-1" />
                      <span className="text-sm">{call.time}</span>
                    </div>
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(call.status)}`}>
                      {getStatusText(call.status)}
                    </span>
                  </div>
                </div>
              </div>

              {call.status === 'scheduled' && (
                <button
                  onClick={() => handleJoinCall(call.id)}
                  className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  <Video className="w-4 h-4 mr-2" />
                  Görüşmeye Katıl
                </button>
              )}
            </div>
          </div>
        ))}

        {calls.length === 0 && (
          <div className="p-6 text-center text-gray-500">
            Bu tarih için planlanmış görüşme bulunmuyor.
          </div>
        )}
      </div>
    </div>
  );
}