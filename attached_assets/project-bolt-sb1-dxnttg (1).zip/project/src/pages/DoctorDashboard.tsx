import React from 'react';
import { Calendar, Users, Clock, MessageSquare, FileText, Settings } from 'lucide-react';

const DoctorDashboard = () => {
  const appointments = [
    { id: 1, patient: 'Ayşe Yılmaz', time: '09:00', type: 'Video Görüşme', status: 'Bekliyor' },
    { id: 2, patient: 'Mehmet Demir', time: '10:30', type: 'Mesajlaşma', status: 'Onaylandı' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <StatCard
            icon={<Users className="h-6 w-6" />}
            title="Toplam Hasta"
            value="248"
            change="+12% geçen ay"
          />
          <StatCard
            icon={<Calendar className="h-6 w-6" />}
            title="Bu Ayki Görüşmeler"
            value="45"
            change="+8% geçen ay"
          />
          <StatCard
            icon={<Clock className="h-6 w-6" />}
            title="Ortalama Görüşme"
            value="18 dk"
            change="-2 dk geçen ay"
          />
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Appointments List */}
          <div className="lg:col-span-2">
            <div className="bg-white shadow rounded-lg">
              <div className="px-4 py-5 border-b border-gray-200 sm:px-6">
                <h3 className="text-lg font-medium text-gray-900">Günün Randevuları</h3>
              </div>
              <ul className="divide-y divide-gray-200">
                {appointments.map((appointment) => (
                  <li key={appointment.id} className="px-4 py-4 sm:px-6 hover:bg-gray-50">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-blue-600">{appointment.patient}</p>
                        <p className="text-sm text-gray-500">{appointment.type}</p>
                      </div>
                      <div className="flex items-center">
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                          {appointment.status}
                        </span>
                        <span className="ml-4 text-sm text-gray-500">{appointment.time}</span>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="space-y-6">
            <div className="bg-white shadow rounded-lg p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Hızlı İşlemler</h3>
              <div className="grid grid-cols-2 gap-4">
                <QuickActionButton
                  icon={<Calendar className="h-5 w-5" />}
                  title="Randevu Oluştur"
                />
                <QuickActionButton
                  icon={<MessageSquare className="h-5 w-5" />}
                  title="Mesajlar"
                />
                <QuickActionButton
                  icon={<FileText className="h-5 w-5" />}
                  title="Raporlar"
                />
                <QuickActionButton
                  icon={<Settings className="h-5 w-5" />}
                  title="Ayarlar"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ icon, title, value, change }: { icon: React.ReactNode, title: string, value: string, change: string }) => (
  <div className="bg-white shadow rounded-lg p-6">
    <div className="flex items-center">
      <div className="p-3 rounded-full bg-blue-100 text-blue-600">
        {icon}
      </div>
      <div className="ml-4">
        <p className="text-sm font-medium text-gray-500">{title}</p>
        <p className="text-2xl font-semibold text-gray-900">{value}</p>
        <p className="text-sm text-gray-500">{change}</p>
      </div>
    </div>
  </div>
);

const QuickActionButton = ({ icon, title }: { icon: React.ReactNode, title: string }) => (
  <button className="flex flex-col items-center justify-center p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
    <div className="text-blue-600 mb-2">{icon}</div>
    <span className="text-sm font-medium text-gray-900">{title}</span>
  </button>
);

export default DoctorDashboard;