import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Phone, Mail, Check, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface DoctorAppointment {
  id: string;
  patientName: string;
  patientId: string;
  date: string;
  time: string;
  type: 'in-person' | 'video' | 'chat';
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  contact: {
    phone: string;
    email: string;
  };
  notes?: string;
}

const mockAppointments: DoctorAppointment[] = [
  {
    id: '1',
    patientName: 'Ahmet Yılmaz',
    patientId: 'p1',
    date: '2024-03-15',
    time: '09:00',
    type: 'in-person',
    status: 'pending',
    contact: {
      phone: '+90 532 123 4567',
      email: 'ahmet@example.com'
    }
  },
  {
    id: '2',
    patientName: 'Ayşe Kaya',
    patientId: 'p2',
    date: '2024-03-15',
    time: '10:00',
    type: 'video',
    status: 'confirmed',
    contact: {
      phone: '+90 533 234 5678',
      email: 'ayse@example.com'
    }
  }
];

export default function DoctorAppointments() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState(mockAppointments);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const handleConfirm = (appointmentId: string) => {
    setAppointments(prev => prev.map(app => 
      app.id === appointmentId ? { ...app, status: 'confirmed' } : app
    ));
  };

  const handleCancel = (appointmentId: string) => {
    setAppointments(prev => prev.map(app => 
      app.id === appointmentId ? { ...app, status: 'cancelled' } : app
    ));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'confirmed':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'Onay Bekliyor';
      case 'confirmed':
        return 'Onaylandı';
      case 'completed':
        return 'Tamamlandı';
      case 'cancelled':
        return 'İptal Edildi';
      default:
        return status;
    }
  };

  const getTypeText = (type: string) => {
    switch (type) {
      case 'in-person':
        return 'Yüz Yüze';
      case 'video':
        return 'Görüntülü';
      case 'chat':
        return 'Mesajlaşma';
      default:
        return type;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">Randevularım</h2>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      <div className="divide-y divide-gray-200">
        {appointments.map((appointment) => (
          <div key={appointment.id} className="p-6 hover:bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center">
                  <h3 className="text-lg font-medium text-gray-900">
                    {appointment.patientName}
                  </h3>
                  <span className={`ml-4 px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(appointment.status)}`}>
                    {getStatusText(appointment.status)}
                  </span>
                  <span className="ml-4 px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                    {getTypeText(appointment.type)}
                  </span>
                </div>

                <div className="mt-2 grid grid-cols-2 gap-4">
                  <div className="flex items-center text-gray-500">
                    <Calendar className="w-4 h-4 mr-2" />
                    {new Date(appointment.date).toLocaleDateString()}
                  </div>
                  <div className="flex items-center text-gray-500">
                    <Clock className="w-4 h-4 mr-2" />
                    {appointment.time}
                  </div>
                  <div className="flex items-center text-gray-500">
                    <Phone className="w-4 h-4 mr-2" />
                    {appointment.contact.phone}
                  </div>
                  <div className="flex items-center text-gray-500">
                    <Mail className="w-4 h-4 mr-2" />
                    {appointment.contact.email}
                  </div>
                </div>
              </div>

              {appointment.status === 'pending' && (
                <div className="flex space-x-3">
                  <button
                    onClick={() => handleConfirm(appointment.id)}
                    className="flex items-center px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Onayla
                  </button>
                  <button
                    onClick={() => handleCancel(appointment.id)}
                    className="flex items-center px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Reddet
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}

        {appointments.length === 0 && (
          <div className="p-6 text-center text-gray-500">
            Bu tarih için randevu bulunmuyor.
          </div>
        )}
      </div>
    </div>
  );
}