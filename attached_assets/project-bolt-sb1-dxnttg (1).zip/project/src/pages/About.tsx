import React from 'react';
import { Shield, Users, Award, Heart, Star, Clock, Building, Globe } from 'lucide-react';

export default function About() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-primary-600 to-secondary-500 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-bold mb-4">Kurumsal</h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            OnlineSağlık, modern teknoloji ve tıbbi uzmanlığı bir araya getiren, 
            uzaktan sağlık hizmetleri alanında öncü bir dijital sağlık platformudur. 
            Güvenli, erişilebilir ve kaliteli sağlık danışmanlığı hizmetleri sunuyoruz.
          </p>
        </div>
      </div>

      {/* Values Section */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Kurumsal Değerlerimiz</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <ValueCard
              icon={Shield}
              title="Veri Güvenliği"
              description="En yüksek güvenlik standartları ile kişisel ve sağlık verilerinizi koruyoruz."
            />
            <ValueCard
              icon={Users}
              title="Kolay Erişim"
              description="7/24 kesintisiz hizmet anlayışıyla sağlık danışmanlığını herkes için ulaşılabilir kılıyoruz."
            />
            <ValueCard
              icon={Award}
              title="Uzman Kadro"
              description="Alanında deneyimli, akademik kariyere sahip uzman hekimlerimizle hizmet veriyoruz."
            />
            <ValueCard
              icon={Heart}
              title="Hasta Odaklılık"
              description="Her zaman hasta memnuniyetini ve kaliteli hizmet sunumunu önceliklendiriyoruz."
            />
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <StatCard 
              icon={Building}
              number="15+" 
              text="Uzmanlık Alanı" 
            />
            <StatCard 
              icon={Users}
              number="10,000+" 
              text="Aktif Kullanıcı" 
            />
            <StatCard 
              icon={Star}
              number="50+" 
              text="Uzman Hekim" 
            />
            <StatCard 
              icon={Clock}
              number="24/7" 
              text="Kesintisiz Hizmet" 
            />
          </div>
        </div>
      </div>

      {/* Mission Section */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Misyonumuz</h2>
            <p className="text-lg text-gray-600">
              OnlineSağlık olarak, modern teknoloji ve tıbbi uzmanlığı bir araya getirerek, 
              kaliteli sağlık danışmanlığı hizmetlerini dijital platformda sunmayı hedefliyoruz. 
              Hasta güvenliği ve memnuniyetini ön planda tutarak, sürdürülebilir ve yenilikçi 
              sağlık çözümleri geliştirmeye devam ediyoruz.
            </p>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Neden OnlineSağlık?</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FeatureCard
              title="Uzman Hekim Kadrosu"
              description="Alanında uzman, deneyimli ve akademik kariyere sahip hekimlerimizle hizmet veriyoruz."
            />
            <FeatureCard
              title="Güvenli Altyapı"
              description="En son teknolojiler ve güvenlik protokolleri ile verilerinizi koruyoruz."
            />
            <FeatureCard
              title="Yapay Zeka Desteği"
              description="Gelişmiş yapay zeka teknolojimiz ile ön değerlendirme ve yönlendirme hizmeti sunuyoruz."
            />
          </div>
        </div>
      </div>

      {/* Legal Notice */}
      <div className="bg-white py-8">
        <div className="max-w-3xl mx-auto px-4 text-center text-sm text-gray-600">
          <p>
            OnlineSağlık, uzman hekimlerle iletişimi kolaylaştıran bir dijital sağlık platformudur. 
            Platformumuz üzerinden sunulan hizmetler, yüz yüze muayenenin yerini tutmamakta olup, 
            gerekli durumlarda kullanıcılarımız ilgili sağlık kuruluşlarına yönlendirilmektedir.
          </p>
        </div>
      </div>
    </div>
  );
}

const ValueCard = ({ icon: Icon, title, description }: { icon: any, title: string, description: string }) => (
  <div className="text-center p-6 bg-white rounded-lg shadow-soft hover:shadow-lg transition-all duration-300">
    <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
      <Icon className="w-6 h-6 text-primary-600" />
    </div>
    <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
);

const StatCard = ({ icon: Icon, number, text }: { icon: any, number: string, text: string }) => (
  <div className="text-center bg-white rounded-lg shadow-soft p-6 hover:shadow-lg transition-all duration-300">
    <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
      <Icon className="w-6 h-6 text-primary-600" />
    </div>
    <div className="text-4xl font-bold text-primary-600 mb-2">{number}</div>
    <div className="text-gray-600">{text}</div>
  </div>
);

const FeatureCard = ({ title, description }: { title: string, description: string }) => (
  <div className="bg-white rounded-lg shadow-soft p-6 hover:shadow-lg transition-all duration-300">
    <h3 className="text-xl font-semibold text-gray-900 mb-3">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
);