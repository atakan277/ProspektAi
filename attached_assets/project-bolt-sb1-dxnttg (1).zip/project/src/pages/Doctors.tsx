import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Star, Calendar, MessageSquare, Filter } from 'lucide-react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';

export default function Doctors() {
  const { users } = useData();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    minRating: 0,
    minExperience: 0,
    title: ''
  });

  // Get all approved doctors
  const doctors = users.filter(u => 
    u.role === 'doctor' && 
    u.doctorInfo?.status === 'approved'
  );

  // Get unique specialties
  const specialties = Array.from(new Set(doctors
    .map(d => d.doctorInfo?.specialty)
    .filter(Boolean)));

  const filteredDoctors = doctors.filter(doctor => {
    const matchesSearch = 
      doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      doctor.doctorInfo?.specialty?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesSpecialty = !selectedSpecialty || doctor.doctorInfo?.specialty === selectedSpecialty;
    const matchesRating = doctor.doctorInfo?.rating ? doctor.doctorInfo.rating >= filters.minRating : true;
    const matchesExperience = doctor.doctorInfo?.experience ? doctor.doctorInfo.experience >= filters.minExperience : true;
    const matchesTitle = !filters.title || doctor.doctorInfo?.title === filters.title;

    return matchesSearch && matchesSpecialty && matchesRating && matchesExperience && matchesTitle;
  });

  const handleAction = (e: React.MouseEvent, type: 'appointment' | 'message', doctorId: string) => {
    e.preventDefault();
    
    if (!user) {
      navigate('/login', { state: { from: `/doctors` } });
      return;
    }

    switch (type) {
      case 'appointment':
        navigate(`/appointments/schedule/${doctorId}`);
        break;
      case 'message':
        navigate(`/messages/${doctorId}`);
        break;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Uzman Hekimlerimiz</h1>
        
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Doktor adı veya uzmanlık alanı ara..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <select
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            value={selectedSpecialty}
            onChange={(e) => setSelectedSpecialty(e.target.value)}
          >
            <option value="">Tüm Uzmanlık Alanları</option>
            {specialties.map(specialty => (
              <option key={specialty} value={specialty}>{specialty}</option>
            ))}
          </select>

          <button
            onClick={() => setShowFilters(!showFilters)}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center"
          >
            <Filter className="w-4 h-4 mr-2" />
            Filtreler
          </button>
        </div>

        {showFilters && (
          <div className="mt-4 p-4 bg-white rounded-lg shadow">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Minimum Puan
                </label>
                <select
                  value={filters.minRating}
                  onChange={(e) => setFilters({ ...filters, minRating: Number(e.target.value) })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value={0}>Tümü</option>
                  <option value={4}>4.0+</option>
                  <option value={4.5}>4.5+</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Minimum Deneyim
                </label>
                <select
                  value={filters.minExperience}
                  onChange={(e) => setFilters({ ...filters, minExperience: Number(e.target.value) })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value={0}>Tümü</option>
                  <option value={5}>5+ Yıl</option>
                  <option value={10}>10+ Yıl</option>
                  <option value={15}>15+ Yıl</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Unvan
                </label>
                <select
                  value={filters.title}
                  onChange={(e) => setFilters({ ...filters, title: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">Tümü</option>
                  <option value="Prof. Dr.">Prof. Dr.</option>
                  <option value="Doç. Dr.">Doç. Dr.</option>
                  <option value="Uzm. Dr.">Uzm. Dr.</option>
                  <option value="Op. Dr.">Op. Dr.</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDoctors.map((doctor) => (
          <Link
            key={doctor.id}
            to={`/doctors/${doctor.id}`}
            className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
          >
            <div className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center">
                  {doctor.profileImage ? (
                    <img
                      src={doctor.profileImage}
                      alt={doctor.name}
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <span className="text-2xl font-bold text-gray-400">
                      {doctor.name.charAt(0)}
                    </span>
                  )}
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{doctor.name}</h3>
                  <p className="text-sm text-gray-600">{doctor.doctorInfo?.title}</p>
                  <p className="text-sm text-gray-600">{doctor.doctorInfo?.specialty}</p>
                  <div className="flex items-center mt-1">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="ml-1 text-sm text-gray-600">
                      {doctor.doctorInfo?.rating}
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-4">
                <p className="text-sm text-gray-600">
                  {doctor.doctorInfo?.experience} yıl deneyim
                </p>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2">
                <button
                  onClick={(e) => handleAction(e, 'appointment', doctor.id)}
                  className="flex items-center justify-center space-x-1 bg-blue-600 text-white py-2 px-3 rounded-lg hover:bg-blue-700 transition-colors text-sm"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Randevu Al</span>
                </button>
                <button
                  onClick={(e) => handleAction(e, 'message', doctor.id)}
                  className="flex items-center justify-center space-x-1 bg-purple-600 text-white py-2 px-3 rounded-lg hover:bg-purple-700 transition-colors text-sm"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Mesaj Gönder</span>
                </button>
              </div>
            </div>
          </Link>
        ))}

        {filteredDoctors.length === 0 && (
          <div className="col-span-full text-center py-12 text-gray-500">
            Arama kriterlerinize uygun doktor bulunamadı.
          </div>
        )}
      </div>
    </div>
  );
}