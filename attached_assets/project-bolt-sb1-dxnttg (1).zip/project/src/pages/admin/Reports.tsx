import React, { useState } from 'react';
import { Calendar, Download, Filter, ChevronDown } from 'lucide-react';

interface Report {
  id: string;
  type: 'user' | 'appointment' | 'financial' | 'system';
  title: string;
  date: string;
  summary: string;
  downloadUrl?: string;
}

const mockReports: Report[] = [
  {
    id: '1',
    type: 'user',
    title: 'Kullanıcı Aktivite Raporu',
    date: '2024-03-15',
    summary: 'Günlük kullanıcı aktiviteleri ve etkileşim istatistikleri',
    downloadUrl: '#'
  },
  {
    id: '2',
    type: 'appointment',
    title: 'Randevu İstatistikleri',
    date: '2024-03-14',
    summary: 'Haftalık randevu durumları ve tamamlanma oranları',
    downloadUrl: '#'
  },
  {
    id: '3',
    type: 'financial',
    title: 'Gelir Raporu',
    date: '2024-03-13',
    summary: 'Aylık gelir ve kredi kullanım analizi',
    downloadUrl: '#'
  }
];

export default function AdminReports() {
  const [reports, setReports] = useState(mockReports);
  const [selectedType, setSelectedType] = useState<string>('all');
  const [dateRange, setDateRange] = useState({
    start: '',
    end: ''
  });

  const filteredReports = reports.filter(report => {
    if (selectedType !== 'all' && report.type !== selectedType) return false;
    if (dateRange.start && new Date(report.date) < new Date(dateRange.start)) return false;
    if (dateRange.end && new Date(report.date) > new Date(dateRange.end)) return false;
    return true;
  });

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">Raporlar</h2>
          <div className="flex space-x-4">
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">Tüm Raporlar</option>
              <option value="user">Kullanıcı Raporları</option>
              <option value="appointment">Randevu Raporları</option>
              <option value="financial">Finansal Raporlar</option>
              <option value="system">Sistem Raporları</option>
            </select>
            <div className="flex space-x-2">
              <input
                type="date"
                value={dateRange.start}
                onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <input
                type="date"
                value={dateRange.end}
                onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="divide-y divide-gray-200">
        {filteredReports.map((report) => (
          <div key={report.id} className="p-6 hover:bg-gray-50">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-medium text-gray-900">
                  {report.title}
                </h3>
                <div className="mt-1 flex items-center text-sm text-gray-500">
                  <Calendar className="w-4 h-4 mr-2" />
                  {new Date(report.date).toLocaleDateString()}
                </div>
                <p className="mt-2 text-gray-600">{report.summary}</p>
              </div>

              {report.downloadUrl && (
                <button
                  onClick={() => window.open(report.downloadUrl, '_blank')}
                  className="flex items-center px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                >
                  <Download className="w-4 h-4 mr-2" />
                  İndir
                </button>
              )}
            </div>
          </div>
        ))}

        {filteredReports.length === 0 && (
          <div className="p-6 text-center text-gray-500">
            Seçilen kriterlere uygun rapor bulunamadı.
          </div>
        )}
      </div>
    </div>
  );
}