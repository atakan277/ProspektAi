import React, { useState } from 'react';
import { Save, Bell, Shield, Lock } from 'lucide-react';
import type { AdminSettings } from '../../types/admin';

export default function AdminSettings() {
  const [settings, setSettings] = useState<AdminSettings>({
    autoApproveVerifiedDoctors: false,
    requirePhoneVerification: true,
    maxLoginAttempts: 5,
    sessionTimeout: 30,
    maintenanceMode: false,
    notificationSettings: {
      emailNotifications: true,
      pushNotifications: true,
      dailyReports: true
    },
    securitySettings: {
      twoFactorAuth: true,
      ipWhitelist: [],
      passwordPolicy: {
        minLength: 8,
        requireSpecialChars: true,
        requireNumbers: true,
        requireUppercase: true,
        expirationDays: 90
      }
    }
  });

  const handleSave = () => {
    // API call will be implemented here
    alert('Ayarlar kaydedildi');
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-2xl font-bold text-gray-900">Sistem Ayarları</h2>
      </div>

      <div className="p-6 space-y-8">
        {/* Genel Ayarlar */}
        <section>
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            <Shield className="inline-block w-5 h-5 mr-2" />
            Güvenlik Ayarları
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <label className="font-medium text-gray-700">
                  İki Faktörlü Doğrulama
                </label>
                <p className="text-sm text-gray-500">
                  Admin girişleri için zorunlu 2FA
                </p>
              </div>
              <div className="relative inline-block w-12 h-6">
                <input
                  type="checkbox"
                  checked={settings.securitySettings.twoFactorAuth}
                  onChange={(e) => setSettings({
                    ...settings,
                    securitySettings: {
                      ...settings.securitySettings,
                      twoFactorAuth: e.target.checked
                    }
                  })}
                  className="sr-only"
                />
                <div className={`block w-12 h-6 rounded-full ${
                  settings.securitySettings.twoFactorAuth ? 'bg-blue-600' : 'bg-gray-200'
                }`} />
                <div className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${
                  settings.securitySettings.twoFactorAuth ? 'transform translate-x-6' : ''
                }`} />
              </div>
            </div>

            <div>
              <label className="font-medium text-gray-700">
                IP Whitelist
              </label>
              <div className="mt-1 flex space-x-2">
                <input
                  type="text"
                  placeholder="IP adresi ekle"
                  className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
                <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                  Ekle
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Bildirim Ayarları */}
        <section>
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            <Bell className="inline-block w-5 h-5 mr-2" />
            Bildirim Ayarları
          </h3>
          <div className="space-y-4">
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={settings.notificationSettings.emailNotifications}
                onChange={(e) => setSettings({
                  ...settings,
                  notificationSettings: {
                    ...settings.notificationSettings,
                    emailNotifications: e.target.checked
                  }
                })}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label className="ml-2 block text-sm text-gray-700">
                E-posta Bildirimleri
              </label>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={settings.notificationSettings.pushNotifications}
                onChange={(e) => setSettings({
                  ...settings,
                  notificationSettings: {
                    ...settings.notificationSettings,
                    pushNotifications: e.target.checked
                  }
                })}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label className="ml-2 block text-sm text-gray-700">
                Push Bildirimleri
              </label>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={settings.notificationSettings.dailyReports}
                onChange={(e) => setSettings({
                  ...settings,
                  notificationSettings: {
                    ...settings.notificationSettings,
                    dailyReports: e.target.checked
                  }
                })}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label className="ml-2 block text-sm text-gray-700">
                Günlük Raporlar
              </label>
            </div>
          </div>
        </section>

        {/* Bakım Modu */}
        <section>
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            <Lock className="inline-block w-5 h-5 mr-2" />
             Bakım Modu
          </h3>
          <div className="bg-yellow-50 p-4 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <label className="font-medium text-yellow-800">
                  Bakım Modu
                </label>
                <p className="text-sm text-yellow-700">
                  Sistemi bakım moduna al (Tüm kullanıcılar için erişim kısıtlanır)
                </p>
              </div>
              <div className="relative inline-block w-12 h-6">
                <input
                  type="checkbox"
                  checked={settings.maintenanceMode}
                  onChange={(e) => setSettings({
                    ...settings,
                    maintenanceMode: e.target.checked
                  })}
                  className="sr-only"
                />
                <div className={`block w-12 h-6 rounded-full ${
                  settings.maintenanceMode ? 'bg-yellow-600' : 'bg-gray-200'
                }`} />
                <div className={`absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${
                  settings.maintenanceMode ? 'transform translate-x-6' : ''
                }`} />
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Save Button */}
      <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
        <button
          onClick={handleSave}
          className="w-full flex justify-center items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Save className="w-4 h-4 mr-2" />
          Ayarları Kaydet
        </button>
      </div>
    </div>
  );
}