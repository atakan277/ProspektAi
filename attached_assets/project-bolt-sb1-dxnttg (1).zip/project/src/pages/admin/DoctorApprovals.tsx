import React, { useState } from 'react';
import { Search, Check, X, Eye, FileText } from 'lucide-react';
import { useData } from '../../context/DataContext';

export default function DoctorApprovals() {
  const { doctorApplications, updateDoctorApplication } = useData();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedApplication, setSelectedApplication] = useState<any>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [showRejectionModal, setShowRejectionModal] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState('');

  const filteredApplications = doctorApplications.filter(app => 
    app.doctorInfo.status === 'pending' &&
    (app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
     app.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
     app.doctorInfo.specialty.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleApprove = (applicationId: string) => {
    updateDoctorApplication(applicationId, 'approved');
    setShowSuccessMessage('Doktor başvurusu onaylandı');
    setTimeout(() => setShowSuccessMessage(''), 3000);
  };

  const handleReject = () => {
    if (!selectedApplication || !rejectionReason) return;

    updateDoctorApplication(selectedApplication.id, 'rejected', rejectionReason);
    setShowSuccessMessage('Doktor başvurusu reddedildi');
    setShowRejectionModal(false);
    setSelectedApplication(null);
    setRejectionReason('');
    setTimeout(() => setShowSuccessMessage(''), 3000);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">Doktor Başvuruları</h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Doktor ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {showSuccessMessage && (
        <div className="m-4 p-4 bg-green-100 text-green-700 rounded-lg">
          {showSuccessMessage}
        </div>
      )}

      <div className="divide-y divide-gray-200">
        {filteredApplications.map((application) => (
          <div key={application.id} className="p-6 hover:bg-gray-50">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-medium text-gray-900">
                  {application.name}
                </h3>
                <div className="mt-1 space-y-1">
                  <p className="text-sm text-gray-600">{application.email}</p>
                  <p className="text-sm text-gray-600">
                    {application.doctorInfo.specialty} - {application.doctorInfo.title}
                  </p>
                  <p className="text-sm text-gray-600">
                    {application.doctorInfo.verification.university}, {application.doctorInfo.verification.graduationYear}
                  </p>
                </div>
              </div>

              <div className="flex space-x-3">
                <button
                  onClick={() => handleApprove(application.id)}
                  className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  <Check className="w-4 h-4 mr-2" />
                  Onayla
                </button>
                <button
                  onClick={() => {
                    setSelectedApplication(application);
                    setShowRejectionModal(true);
                  }}
                  className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  <X className="w-4 h-4 mr-2" />
                  Reddet
                </button>
                <button
                  onClick={() => window.open('#', '_blank')}
                  className="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Belgeler
                </button>
              </div>
            </div>
          </div>
        ))}

        {filteredApplications.length === 0 && (
          <div className="p-6 text-center text-gray-500">
            Bekleyen başvuru bulunmuyor.
          </div>
        )}
      </div>

      {/* Rejection Modal */}
      {showRejectionModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Başvuru Reddetme
            </h3>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Red Nedeni
              </label>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                rows={4}
                className="w-full rounded-lg border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500"
                placeholder="Red nedenini açıklayın..."
                required
              />
            </div>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => {
                  setShowRejectionModal(false);
                  setSelectedApplication(null);
                  setRejectionReason('');
                }}
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
              >
                İptal
              </button>
              <button
                onClick={handleReject}
                disabled={!rejectionReason.trim()}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50"
              >
                Reddet
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}