import React from 'react';
import { useData } from '../../context/DataContext';
import { Users, UserCheck, CreditCard, Activity } from 'lucide-react';

export default function AdminDashboard() {
  const { users, appointments } = useData();

  // Calculate admin stats
  const stats = {
    totalPatients: users.filter(u => u.role === 'patient').length,
    totalDoctors: users.filter(u => u.role === 'doctor' && u.doctorInfo?.status === 'approved').length,
    pendingDoctors: users.filter(u => u.role === 'doctor' && u.doctorInfo?.status === 'pending').length,
    activeAppointments: appointments.filter(a => a.status === 'upcoming').length
  };

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard
          icon={<Users className="h-6 w-6 text-blue-600" />}
          title="Toplam Hasta"
          value={stats.totalPatients}
          bgColor="bg-blue-50"
        />
        <StatCard
          icon={<UserCheck className="h-6 w-6 text-green-600" />}
          title="Toplam Doktor"
          value={stats.totalDoctors}
          bgColor="bg-green-50"
        />
        <StatCard
          icon={<Activity className="h-6 w-6 text-purple-600" />}
          title="Bekleyen Onaylar"
          value={stats.pendingDoctors}
          bgColor="bg-purple-50"
        />
        <StatCard
          icon={<CreditCard className="h-6 w-6 text-orange-600" />}
          title="Aktif Randevular"
          value={stats.activeAppointments}
          bgColor="bg-orange-50"
        />
      </div>

      {/* Recent Applications */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Son Doktor Başvuruları</h2>
        <div className="space-y-4">
          {users
            .filter(u => u.role === 'doctor' && u.doctorInfo?.status === 'pending')
            .slice(0, 5)
            .map((doctor) => (
              <div key={doctor.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">{doctor.name}</p>
                  <p className="text-sm text-gray-600">
                    {doctor.doctorInfo?.specialty} - {doctor.doctorInfo?.title}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-600">
                    {doctor.email}
                  </p>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                    Onay Bekliyor
                  </span>
                </div>
              </div>
            ))}

          {stats.pendingDoctors === 0 && (
            <div className="text-center text-gray-500 py-4">
              Bekleyen başvuru bulunmuyor
            </div>
          )}
        </div>
      </div>

      {/* Recent Users */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Son Kayıt Olan Kullanıcılar</h2>
        <div className="space-y-4">
          {users.slice(-5).map((user) => (
            <div key={user.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium">{user.name}</p>
                <p className="text-sm text-gray-600">{user.email}</p>
              </div>
              <div>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  user.role === 'doctor' ? 'bg-blue-100 text-blue-800' :
                  user.role === 'admin' ? 'bg-red-100 text-red-800' :
                  'bg-green-100 text-green-800'
                }`}>
                  {user.role === 'doctor' ? 'Doktor' :
                   user.role === 'admin' ? 'Admin' : 'Hasta'}
                </span>
              </div>
            </div>
          ))}

          {users.length === 0 && (
            <div className="text-center text-gray-500 py-4">
              Henüz kullanıcı bulunmuyor
            </div>
          )}
        </div>
      </div>

      {/* Recent Appointments */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-semibold mb-4">Son Randevular</h2>
        <div className="space-y-4">
          {appointments.slice(-5).map((appointment) => (
            <div key={appointment.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium">{appointment.doctorName}</p>
                <p className="text-sm text-gray-600">{appointment.specialty}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium">
                  {new Date(appointment.date).toLocaleDateString()}
                </p>
                <p className="text-sm text-gray-600">{appointment.time}</p>
              </div>
            </div>
          ))}

          {appointments.length === 0 && (
            <div className="text-center text-gray-500 py-4">
              Henüz randevu bulunmuyor
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

const StatCard = ({ 
  icon, 
  title, 
  value, 
  bgColor 
}: { 
  icon: React.ReactNode;
  title: string;
  value: number;
  bgColor: string;
}) => (
  <div className={`${bgColor} rounded-lg p-6`}>
    <div className="flex items-center justify-between">
      {icon}
      <span className="text-2xl font-bold">{value}</span>
    </div>
    <p className="mt-2 text-sm text-gray-600">{title}</p>
  </div>
);