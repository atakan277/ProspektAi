import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Package, Shield } from 'lucide-react';

const packages = [
  { id: 1, credits: 100, price: 199, name: 'Başlangıç Paketi' },
  { id: 2, credits: 250, price: 399, name: 'Standart Paket' },
  { id: 3, credits: 500, price: 699, name: 'Premium Paket' },
];

export default function CreditPurchase() {
  const navigate = useNavigate();

  const handlePurchase = (packageId: number) => {
    const selectedPackage = packages.find(p => p.id === packageId);
    if (selectedPackage) {
      navigate('/payment', { 
        state: { 
          package: selectedPackage 
        }
      });
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900">Kredi Paketleri</h2>
        <p className="text-gray-600 mt-2">
          Kredi satın alarak tüm hizmetlerimizden faydalanabilirsiniz
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {packages.map((pkg) => (
          <div key={pkg.id} className="bg-white rounded-lg shadow-lg p-6 border border-gray-200">
            <div className="text-center">
              <Package className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{pkg.name}</h3>
              <div className="text-3xl font-bold text-blue-600 mb-4">
                {pkg.credits} <span className="text-sm text-gray-600">Kredi</span>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-6">
                {pkg.price} TL
              </div>
              <button
                onClick={() => handlePurchase(pkg.id)}
                className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 flex items-center justify-center space-x-2"
              >
                <CreditCard className="w-5 h-5" />
                <span>Satın Al</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 bg-blue-50 p-4 rounded-lg">
        <div className="flex items-start">
          <Shield className="w-5 h-5 text-blue-600 mt-0.5 mr-2" />
          <div className="text-sm text-blue-700">
            <p className="font-medium mb-1">Güvenli Ödeme</p>
            <p>Papara altyapısı ile güvenli ödeme yapabilirsiniz. Kredi kartı bilgileriniz bizimle paylaşılmaz.</p>
          </div>
        </div>
      </div>
    </div>
  );
}