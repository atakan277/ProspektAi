import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Mic, MicOff, Video, VideoOff, Phone, MessageSquare, Share2, Users } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useCredits } from '../../context/CreditContext';

const CREDIT_PER_MINUTE = 50;

export default function VideoCall() {
  const { doctorId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { credits, spendCredits } = useCredits();
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [callDuration, setCallDuration] = useState(0);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    if (credits < CREDIT_PER_MINUTE) {
      alert('Görüntülü görüşme için yeterli krediniz bulunmuyor. Lütfen kredi yükleyin.');
      navigate('/credits');
      return;
    }

    const timer = setInterval(() => {
      setCallDuration(prev => {
        const newDuration = prev + 1;
        if (newDuration % 60 === 0) {
          const success = spendCredits(CREDIT_PER_MINUTE);
          if (!success) {
            alert('Krediniz bitti. Görüşme sonlandırılıyor.');
            navigate('/credits');
          }
        }
        return newDuration;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [credits, navigate, spendCredits, user]);

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gray-900">
      <div className="h-screen flex flex-col">
        <div className="flex-1 flex">
          <div className="flex-1 relative">
            <div className="absolute inset-0 bg-gray-800">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-white text-center">
                  <div className="w-24 h-24 bg-blue-600 rounded-full flex items-center justify-center mb-4 mx-auto">
                    <span className="text-3xl">DR</span>
                  </div>
                  <p className="text-xl font-medium">Dr. Ahmet Yıldız</p>
                  <p className="text-sm text-gray-400 mt-2">Kardiyoloji Uzmanı</p>
                </div>
              </div>
            </div>
            
            <div className="absolute bottom-4 right-4 w-48 h-36 bg-gray-700 rounded-lg shadow-lg">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-white">
                  <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mb-2">
                    <span className="text-sm">SİZ</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="absolute top-4 left-4 bg-black bg-opacity-50 rounded-lg px-4 py-2 text-white">
              <p className="text-sm">Süre: {formatDuration(callDuration)}</p>
              <p className="text-sm">Kalan Kredi: {credits}</p>
            </div>
          </div>
        </div>

        <div className="bg-gray-800 px-4 py-3">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex space-x-4">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className={`p-3 rounded-full ${
                  isMuted ? 'bg-red-600 hover:bg-red-700' : 'bg-gray-700 hover:bg-gray-600'
                }`}
              >
                {isMuted ? (
                  <MicOff className="h-6 w-6 text-white" />
                ) : (
                  <Mic className="h-6 w-6 text-white" />
                )}
              </button>
              <button
                onClick={() => setIsVideoOn(!isVideoOn)}
                className={`p-3 rounded-full ${
                  !isVideoOn ? 'bg-red-600 hover:bg-red-700' : 'bg-gray-700 hover:bg-gray-600'
                }`}
              >
                {isVideoOn ? (
                  <Video className="h-6 w-6 text-white" />
                ) : (
                  <VideoOff className="h-6 w-6 text-white" />
                )}
              </button>
            </div>

            <button 
              onClick={() => navigate('/dashboard')}
              className="p-3 rounded-full bg-red-600 hover:bg-red-700"
            >
              <Phone className="h-6 w-6 text-white" />
            </button>

            <div className="flex space-x-4">
              <button
                onClick={() => setIsChatOpen(!isChatOpen)}
                className="p-3 rounded-full bg-gray-700 hover:bg-gray-600"
              >
                <MessageSquare className="h-6 w-6 text-white" />
              </button>
              <button className="p-3 rounded-full bg-gray-700 hover:bg-gray-600">
                <Share2 className="h-6 w-6 text-white" />
              </button>
              <button className="p-3 rounded-full bg-gray-700 hover:bg-gray-600">
                <Users className="h-6 w-6 text-white" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}