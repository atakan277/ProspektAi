import React from 'react';
import { Calendar, Clock, MapPin, Phone, Mail } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useCredits } from '../../context/CreditContext';
import { useNavigate } from 'react-router-dom';
import { mockAppointments } from '../../data/mockAppointments';
import type { Appointment } from '../../types/appointment';

const RESCHEDULE_COST = 50;
const APPOINTMENT_COST = 150;

export default function Appointments() {
  const { user } = useAuth();
  const { credits, addCredits, spendCredits } = useCredits();
  const navigate = useNavigate();

  const handleReschedule = (appointmentId: string) => {
    if (credits < RESCHEDULE_COST) {
      alert(`Randevu ertelemek için ${RESCHEDULE_COST} krediye ihtiyacınız var. Lütfen kredi yükleyin.`);
      navigate('/credits');
      return;
    }

    const success = spendCredits(RESCHEDULE_COST);
    if (success) {
      navigate(`/appointments/reschedule/${appointmentId}`);
    }
  };

  const handleCancel = (appointmentId: string) => {
    const refundAmount = Math.floor(APPOINTMENT_COST / 2);
    const confirmed = window.confirm(
      `Randevuyu iptal etmek istediğinize emin misiniz? İptal durumunda ${refundAmount} kredi iade edilecektir.`
    );

    if (confirmed) {
      addCredits(refundAmount);
      alert(`Randevunuz iptal edildi ve ${refundAmount} kredi hesabınıza iade edildi.`);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">Randevularım</h2>
        </div>

        <div className="divide-y divide-gray-200">
          {mockAppointments.map((appointment) => (
            <div key={appointment.id} className="p-6 hover:bg-gray-50">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-medium text-gray-900">
                    {appointment.title} {appointment.doctorName}
                  </h3>
                  <p className="text-gray-600">{appointment.specialty}</p>

                  <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center text-gray-500">
                      <Calendar className="w-4 h-4 mr-2" />
                      {new Date(appointment.date).toLocaleDateString()}
                    </div>
                    <div className="flex items-center text-gray-500">
                      <Clock className="w-4 h-4 mr-2" />
                      {appointment.time}
                    </div>
                    <div className="flex items-center text-gray-500">
                      <Phone className="w-4 h-4 mr-2" />
                      {appointment.contact.phone}
                    </div>
                    <div className="flex items-center text-gray-500">
                      <Mail className="w-4 h-4 mr-2" />
                      {appointment.contact.email}
                    </div>
                  </div>

                  {appointment.location && (
                    <div className="mt-4 flex items-start text-gray-500">
                      <MapPin className="w-4 h-4 mr-2 mt-1" />
                      <div>
                        <p className="font-medium">{appointment.location.name}</p>
                        <p>{appointment.location.address}</p>
                        <p>{appointment.location.city}</p>
                      </div>
                    </div>
                  )}
                </div>

                {appointment.status === 'upcoming' && (
                  <div className="mt-4 md:mt-0 flex flex-col space-y-2">
                    <button
                      onClick={() => handleReschedule(appointment.id)}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    >
                      Ertele ({RESCHEDULE_COST} Kredi)
                    </button>
                    <button
                      onClick={() => handleCancel(appointment.id)}
                      className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                    >
                      İptal Et
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}

          {mockAppointments.length === 0 && (
            <div className="p-6 text-center text-gray-500">
              Henüz randevunuz bulunmuyor.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}