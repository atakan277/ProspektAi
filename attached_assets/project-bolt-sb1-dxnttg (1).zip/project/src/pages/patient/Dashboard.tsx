import React from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageSquare, Brain, FileText, Activity } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useCredits } from '../../context/CreditContext';

export default function PatientDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { credits } = useCredits();

  const quickActions = [
    {
      icon: MessageSquare,
      title: 'Mesajlaşma',
      description: 'Mesaj gönderin',
      path: '/messages'
    },
    {
      icon: Brain,
      title: 'AI Ön Tanı',
      description: 'Semptomlarınızı analiz edin',
      path: '/ai-chatbot'
    },
    {
      icon: FileText,
      title: 'Raporlarım',
      description: 'Tıbbi kayıtlarınızı görüntüleyin',
      path: '/reports'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Kredi Kartı */}
      <div className="mb-8">
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg shadow-lg p-6 text-white">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm opacity-80">Kalan Kredi</p>
              <p className="text-3xl font-bold">{credits}</p>
            </div>
            <button 
              onClick={() => navigate('/credits')}
              className="px-4 py-2 bg-white text-blue-600 rounded-lg font-medium hover:bg-blue-50"
            >
              Kredi Yükle
            </button>
          </div>
        </div>
      </div>

      {/* Hızlı İşlemler */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {quickActions.map((action) => (
          <button
            key={action.path}
            onClick={() => navigate(action.path)}
            className="bg-white p-6 rounded-lg shadow hover:shadow-md transition-shadow"
          >
            <div className="text-blue-600 mb-3">
              <action.icon className="h-6 w-6" />
            </div>
            <h3 className="text-sm font-medium text-gray-900 mb-1">{action.title}</h3>
            <p className="text-xs text-gray-500">{action.description}</p>
          </button>
        ))}
      </div>

      {/* Son Aktiviteler */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold mb-4">Son Aktiviteler</h2>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center">
              <Activity className="h-5 w-5 text-blue-600 mr-3" />
              <div>
                <p className="font-medium">AI Danışma</p>
                <p className="text-sm text-gray-500">Semptom analizi yapıldı</p>
              </div>
            </div>
            <span className="text-sm text-gray-500">2 saat önce</span>
          </div>
        </div>
      </div>
    </div>
  );
}