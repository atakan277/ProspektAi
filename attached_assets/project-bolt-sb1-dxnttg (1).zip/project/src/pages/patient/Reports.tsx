import React, { useState } from 'react';
import { FileText, Download, Share2, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface HealthRecord {
  id: string;
  type: 'examination' | 'test' | 'imaging' | 'medication';
  title: string;
  date: string;
  description?: string;
  fileUrl?: string;
}

export default function Reports() {
  const navigate = useNavigate();
  const [records, setRecords] = useState<HealthRecord[]>([]);

  const handleShare = (recordId: string) => {
    navigate(`/messages/new?recordId=${recordId}`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">Sağlık Kayıtlarım</h2>
        </div>

        <div className="divide-y divide-gray-200">
          {records.map((record) => (
            <div key={record.id} className="p-6 hover:bg-gray-50">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    {record.title}
                  </h3>
                  <div className="mt-1 flex items-center text-sm text-gray-500">
                    <FileText className="w-4 h-4 mr-2" />
                    {new Date(record.date).toLocaleDateString()}
                  </div>
                  {record.description && (
                    <p className="mt-2 text-gray-600">{record.description}</p>
                  )}
                </div>

                <div className="flex space-x-2">
                  {record.fileUrl && (
                    <button
                      onClick={() => window.open(record.fileUrl, '_blank')}
                      className="p-2 text-gray-600 hover:text-gray-900"
                      title="İndir"
                    >
                      <Download className="w-5 h-5" />
                    </button>
                  )}
                  <button
                    onClick={() => handleShare(record.id)}
                    className="p-2 text-blue-600 hover:text-blue-800"
                    title="Doktorla Paylaş"
                  >
                    <Share2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => {
                      if (window.confirm('Bu kaydı silmek istediğinize emin misiniz?')) {
                        setRecords(prev => prev.filter(r => r.id !== record.id));
                      }
                    }}
                    className="p-2 text-red-600 hover:text-red-800"
                    title="Sil"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}

          {records.length === 0 && (
            <div className="p-6 text-center text-gray-500">
              Henüz sağlık kaydınız bulunmuyor.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}