import React from 'react';
import { Calendar, Clock, MapPin, Phone, Mail, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useCredits } from '../context/CreditContext';
import { useNavigate } from 'react-router-dom';
import { mockAppointments } from '../data/mockAppointments';
import type { Appointment } from '../types/appointment';

const RESCHEDULE_COST = 50;
const APPOINTMENT_COST = 150;

export default function Appointments() {
  const { user } = useAuth();
  const { credits, addCredits, spendCredits } = useCredits();
  const navigate = useNavigate();

  if (!user) {
    navigate('/login');
    return null;
  }

  const handleReschedule = (appointmentId: string) => {
    if (credits < RESCHEDULE_COST) {
      alert(`Randevu ertelemek için ${RESCHEDULE_COST} krediye ihtiyacınız var. Lütfen kredi yükleyin.`);
      navigate('/credits');
      return;
    }

    const success = spendCredits(RESCHEDULE_COST);
    if (success) {
      navigate(`/appointments/reschedule/${appointmentId}`);
    }
  };

  const handleCancel = (appointmentId: string) => {
    const refundAmount = Math.floor(APPOINTMENT_COST / 2);
    const confirmed = window.confirm(
      `Randevuyu iptal etmek istediğinize emin misiniz? İptal durumunda ${refundAmount} kredi iade edilecektir.`
    );

    if (confirmed) {
      addCredits(refundAmount);
      alert(`Randevunuz iptal edildi ve ${refundAmount} kredi hesabınıza iade edildi.`);
      // TODO: Update appointment status in backend
    }
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('tr-TR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      weekday: 'long'
    });
  };

  const getStatusColor = (status: Appointment['status']) => {
    switch (status) {
      case 'upcoming':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-gray-100 text-gray-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: Appointment['status']) => {
    switch (status) {
      case 'upcoming':
        return 'Yaklaşan';
      case 'completed':
        return 'Tamamlandı';
      case 'cancelled':
        return 'İptal Edildi';
      default:
        return status;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Randevularım</h2>
        </div>

        <div className="p-4 bg-blue-50 mx-4 my-4 rounded-lg">
          <div className="flex items-start">
            <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5 mr-2" />
            <div className="text-sm text-blue-700">
              <p className="font-medium mb-1">Randevu Yönetimi Bilgilendirmesi:</p>
              <ul className="list-disc pl-5 space-y-1">
                <li>Randevu erteleme işlemi {RESCHEDULE_COST} kredi karşılığında yapılabilir.</li>
                <li>Randevu iptali durumunda randevu ücretinin yarısı ({Math.floor(APPOINTMENT_COST / 2)} kredi) iade edilir.</li>
                <li>İptal edilen randevular için yeni randevu oluşturmanız gerekir.</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {mockAppointments.map((appointment) => (
            <div key={appointment.id} className="p-6 hover:bg-gray-50">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                <div className="flex-1">
                  <div className="mb-4">
                    <h3 className="text-lg font-medium text-gray-900">
                      {appointment.title} {appointment.doctorName}
                    </h3>
                    <p className="text-sm text-gray-500">{appointment.specialty}</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center text-sm text-gray-500">
                        <Calendar className="w-4 h-4 mr-2" />
                        {formatDate(appointment.date)}
                      </div>
                      <div className="flex items-center text-sm text-gray-500">
                        <Clock className="w-4 h-4 mr-2" />
                        {appointment.time}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center text-sm text-gray-500">
                        <Phone className="w-4 h-4 mr-2" />
                        {appointment.contact.phone}
                      </div>
                      <div className="flex items-center text-sm text-gray-500">
                        <Mail className="w-4 h-4 mr-2" />
                        {appointment.contact.email}
                      </div>
                    </div>
                  </div>

                  {appointment.location && (
                    <div className="mt-4 bg-gray-50 rounded-lg p-3">
                      <div className="flex items-start">
                        <MapPin className="w-4 h-4 mr-2 mt-1 text-gray-400" />
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            {appointment.location.name}
                          </p>
                          <p className="text-sm text-gray-500">
                            {appointment.location.address}
                          </p>
                          <p className="text-sm text-gray-500">
                            {appointment.location.city}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="mt-4 md:mt-0 md:ml-6 flex flex-col items-end space-y-3">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(appointment.status)}`}>
                    {getStatusText(appointment.status)}
                  </span>
                  
                  {appointment.status === 'upcoming' && (
                    <div className="flex flex-col space-y-2">
                      <button
                        onClick={() => handleReschedule(appointment.id)}
                        className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        <span>Randevuyu Ertele ({RESCHEDULE_COST} Kredi)</span>
                      </button>
                      <button
                        onClick={() => handleCancel(appointment.id)}
                        className="flex items-center justify-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                      >
                        <span>Randevuyu İptal Et</span>
                      </button>
                      <p className="text-xs text-gray-500 text-center mt-1">
                        İptal durumunda {Math.floor(APPOINTMENT_COST / 2)} kredi iade edilir
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}

          {mockAppointments.length === 0 && (
            <div className="p-6 text-center text-gray-500">
              Henüz randevunuz bulunmuyor.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}