import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, Mail, Lock, Phone, Building, GraduationCap, FileText, ArrowRight } from 'lucide-react';
import { specialties } from '../data/specialties';

// ... rest of the imports ...

const DoctorRegister = () => {
  // ... existing state and handlers ...

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      {/* ... other JSX ... */}

      <div>
        <label htmlFor="specialty" className="block text-sm font-medium text-gray-700">
          Uzmanlık Alanı
        </label>
        <select
          id="specialty"
          name="specialty"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={formData.specialty}
          onChange={(e) => setFormData({ ...formData, specialty: e.target.value })}
        >
          <option value="">Seçiniz</option>
          {specialties.map((specialty) => (
            <option key={specialty} value={specialty}>
              {specialty}
            </option>
          ))}
        </select>
      </div>

      {/* ... rest of the form ... */}
    </div>
  );
};

export default DoctorRegister;