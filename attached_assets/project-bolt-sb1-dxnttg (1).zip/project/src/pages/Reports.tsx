import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { 
  FileText, 
  Download, 
  Calendar, 
  Search,
  SlidersHorizontal,
  Stethoscope,
  TestTube,
  PlusCircle,
  Share2,
  Trash2,
  Upload
} from 'lucide-react';

interface HealthRecord {
  id: string;
  type: 'examination' | 'test' | 'imaging' | 'medication';
  title: string;
  date: string;
  description?: string;
  fileUrl?: string;
  sharedWith?: string[];
}

const mockRecords: HealthRecord[] = [
  {
    id: '1',
    type: 'examination',
    title: 'Kardiyoloji Muayenesi',
    date: '2024-03-10',
    description: 'Rutin kardiyoloji kontrolü',
  },
  {
    id: '2',
    type: 'test',
    title: 'Kan Tahlili Sonuçları',
    date: '2024-03-08',
    description: 'Açlık kan şekeri, hemogram, kolesterol',
    fileUrl: '#'
  },
  {
    id: '3',
    type: 'imaging',
    title: 'Beyin MR',
    date: '2024-03-05',
    description: 'Kontrol MR görüntülemesi',
    fileUrl: '#'
  },
  {
    id: '4',
    type: 'medication',
    title: 'Düzenli Kullanılan İlaçlar',
    date: '2024-03-01',
    description: 'Coumadin 5mg (Günde 1), Beloc 50mg (Günde 2)'
  }
];

export default function Reports() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newRecord, setNewRecord] = useState<Partial<HealthRecord>>({
    type: 'examination',
    title: '',
    description: '',
    date: new Date().toISOString().split('T')[0]
  });

  if (!user) {
    navigate('/login');
    return null;
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'examination':
        return <Stethoscope className="h-5 w-5 text-blue-600" />;
      case 'test':
        return <TestTube className="h-5 w-5 text-green-600" />;
      case 'imaging':
        return <FileText className="h-5 w-5 text-purple-600" />;
      case 'medication':
        return <TestTube className="h-5 w-5 text-orange-600" />;
      default:
        return <FileText className="h-5 w-5 text-gray-600" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'examination':
        return 'bg-blue-100 text-blue-800';
      case 'test':
        return 'bg-green-100 text-green-800';
      case 'imaging':
        return 'bg-purple-100 text-purple-800';
      case 'medication':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeText = (type: string) => {
    switch (type) {
      case 'examination':
        return 'Muayene';
      case 'test':
        return 'Test Sonucu';
      case 'imaging':
        return 'Görüntüleme';
      case 'medication':
        return 'İlaç';
      default:
        return type;
    }
  };

  const handleAddRecord = () => {
    // Add record logic will be implemented here
    setShowAddModal(false);
  };

  const handleShareRecord = (recordId: string) => {
    navigate(`/messages/new?recordId=${recordId}`);
  };

  const filteredRecords = mockRecords.filter(record => {
    const matchesSearch = 
      record.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = selectedType === 'all' || record.type === selectedType;
    
    return matchesSearch && matchesType;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <h2 className="text-2xl font-bold text-gray-900">Sağlık Kayıtlarım</h2>
            
            <div className="flex space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Kayıt ara..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="relative">
                <SlidersHorizontal className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none"
                >
                  <option value="all">Tüm Kayıtlar</option>
                  <option value="examination">Muayeneler</option>
                  <option value="test">Test Sonuçları</option>
                  <option value="imaging">Görüntüleme</option>
                  <option value="medication">İlaçlar</option>
                </select>
              </div>

              <button
                onClick={() => setShowAddModal(true)}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <PlusCircle className="h-5 w-5 mr-2" />
                Yeni Kayıt
              </button>
            </div>
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {filteredRecords.map((record) => (
            <div key={record.id} className="p-6 hover:bg-gray-50">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3">
                    {getTypeIcon(record.type)}
                    <div>
                      <h3 className="text-lg font-medium text-gray-900">
                        {record.title}
                      </h3>
                      <div className="mt-1 flex items-center space-x-2 text-sm text-gray-500">
                        <Calendar className="h-4 w-4" />
                        <span>{new Date(record.date).toLocaleDateString('tr-TR')}</span>
                      </div>
                    </div>
                  </div>
                  {record.description && (
                    <p className="mt-2 text-sm text-gray-600">
                      {record.description}
                    </p>
                  )}
                </div>

                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getTypeColor(record.type)}`}>
                      {getTypeText(record.type)}
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    {record.fileUrl && (
                      <button
                        onClick={() => window.open(record.fileUrl, '_blank')}
                        className="p-2 text-gray-600 hover:text-gray-900"
                        title="İndir"
                      >
                        <Download className="h-5 w-5" />
                      </button>
                    )}
                    <button
                      onClick={() => handleShareRecord(record.id)}
                      className="p-2 text-blue-600 hover:text-blue-800"
                      title="Doktorla Paylaş"
                    >
                      <Share2 className="h-5 w-5" />
                    </button>
                    <button
                      className="p-2 text-red-600 hover:text-red-800"
                      title="Sil"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {filteredRecords.length === 0 && (
            <div className="p-6 text-center text-gray-500">
              Kayıt bulunamadı
            </div>
          )}
        </div>
      </div>

      {/* Add Record Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Yeni Sağlık Kaydı</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Kayıt Türü</label>
                <select
                  value={newRecord.type}
                  onChange={(e) => setNewRecord({ ...newRecord, type: e.target.value as any })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  <option value="examination">Muayene</option>
                  <option value="test">Test Sonucu</option>
                  <option value="imaging">Görüntüleme</option>
                  <option value="medication">İlaç</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Başlık</label>
                <input
                  type="text"
                  value={newRecord.title}
                  onChange={(e) => setNewRecord({ ...newRecord, title: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Tarih</label>
                <input
                  type="date"
                  value={newRecord.date}
                  onChange={(e) => setNewRecord({ ...newRecord, date: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Açıklama</label>
                <textarea
                  value={newRecord.description}
                  onChange={(e) => setNewRecord({ ...newRecord, description: e.target.value })}
                  rows={3}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Dosya Ekle</label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                  <div className="space-y-1 text-center">
                    <Upload className="mx-auto h-12 w-12 text-gray-400" />
                    <div className="flex text-sm text-gray-600">
                      <label className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500">
                        <span>Dosya Yükle</span>
                        <input type="file" className="sr-only" />
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end space-x-3">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                İptal
              </button>
              <button
                onClick={handleAddRecord}
                className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700"
              >
                Kaydet
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}