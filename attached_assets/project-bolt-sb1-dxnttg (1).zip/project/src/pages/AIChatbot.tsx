import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, Loader } from 'lucide-react';
import { useCredits } from '../context/CreditContext';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { getAIResponse } from '../lib/gemini';
import ChatMessage from '../components/ChatMessage';
import DoctorRecommendation from '../components/DoctorRecommendation';
import { AIMessage, ChatState } from '../types/ai';

const AI_CHAT_COST = 10;

const initialState: ChatState = {
  messages: [
    {
      id: 1,
      type: 'bot',
      content: 'Merhaba! Ben OnlineSağlık\'ın Yapay Zeka Tıbbi Asistanıyım. Lütfen şikayetlerinizi detaylı bir şekilde anlatın. Size yardımcı olmak için buradayım.',
      timestamp: new Date()
    }
  ],
  isLoading: false,
  error: null,
  recommendations: []
};

const AIChatbot = () => {
  const { user } = useAuth();
  const { credits, spendCredits } = useCredits();
  const navigate = useNavigate();
  const [state, setState] = useState<ChatState>(initialState);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user) {
      navigate('/login', { state: { from: '/ai-chatbot' } });
      return;
    }

    if (credits < AI_CHAT_COST) {
      navigate('/credits');
      return;
    }
  }, [user, credits, navigate]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [state.messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || state.isLoading) return;

    if (!user) {
      navigate('/login');
      return;
    }

    if (credits < AI_CHAT_COST) {
      alert('Yetersiz kredi! Lütfen kredi yükleyin.');
      navigate('/credits');
      return;
    }

    const userMessage: AIMessage = {
      id: Date.now(),
      type: 'user',
      content: input,
      timestamp: new Date()
    };

    setState(prev => ({
      ...prev,
      messages: [...prev.messages, userMessage],
      isLoading: true,
      error: null
    }));
    
    setInput('');

    try {
      const response = await getAIResponse(input);
      
      if (response.text) {
        const success = spendCredits(AI_CHAT_COST);
        if (!success) {
          throw new Error('Kredi düşülemedi');
        }
        
        const botMessage: AIMessage = {
          id: Date.now() + 1,
          type: 'bot',
          content: response.text,
          timestamp: new Date()
        };

        setState(prev => ({
          ...prev,
          messages: [...prev.messages, botMessage],
          isLoading: false,
          error: null,
          recommendations: response.recommendations
        }));
      } else {
        throw new Error('AI yanıtı alınamadı');
      }
    } catch (error) {
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: 'Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin.'
      }));
    }
  };

  if (!user || credits < AI_CHAT_COST) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-primary-600 to-secondary-500 px-6 py-4">
            <div className="flex items-center space-x-3">
              <Bot className="h-8 w-8 text-white" />
              <div>
                <h2 className="text-white text-lg font-semibold">Yapay Zeka Tıbbi Asistan</h2>
                <p className="text-white/80 text-sm">Her analiz {AI_CHAT_COST} kredi</p>
              </div>
            </div>
          </div>

          <div className="h-[600px] overflow-y-auto p-6">
            {state.messages.map((message) => (
              <ChatMessage key={message.id} message={message} />
            ))}
            
            {state.recommendations.length > 0 && (
              <div className="mt-6">
                <h3 className="text-lg font-semibold mb-4">Önerilen Doktorlar</h3>
                {state.recommendations.map((rec) => (
                  <DoctorRecommendation
                    key={rec.doctor.id}
                    doctor={rec.doctor}
                    reason={rec.reason}
                  />
                ))}
              </div>
            )}
            
            {state.isLoading && (
              <div className="flex justify-start">
                <div className="flex items-center space-x-2 bg-gray-100 rounded-lg p-4">
                  <Loader className="h-5 w-5 text-primary-600 animate-spin" />
                  <span className="text-gray-600">Analiz ediliyor...</span>
                </div>
              </div>
            )}

            {state.error && (
              <div className="bg-red-100 text-red-600 p-4 rounded-lg mb-4">
                {state.error}
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          <form onSubmit={handleSubmit} className="border-t border-gray-200 p-4">
            <div className="flex space-x-4">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Şikayetlerinizi detaylı bir şekilde yazın..."
                className="flex-1 rounded-lg border border-gray-300 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500"
                disabled={state.isLoading}
              />
              <button
                type="submit"
                className="px-4 py-2 bg-gradient-to-r from-primary-600 to-secondary-500 text-white rounded-lg hover:from-primary-700 hover:to-secondary-600 flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
                disabled={state.isLoading || !input.trim()}
              >
                <span>Gönder</span>
                <Send className="h-4 w-4" />
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AIChatbot;