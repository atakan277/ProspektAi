import React from 'react';
import { Calendar, Video, MessageSquare, CreditCard, FileText, Activity } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useCredits } from '../context/CreditContext';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';

const PatientDashboard = () => {
  const navigate = useNavigate();
  const { credits } = useCredits();
  const { user } = useAuth();
  const { appointments } = useData();

  // Kullanıcıya ait randevuları filtrele
  const userAppointments = appointments.filter(
    app => app.patientId === user?.id
  ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleQuickAction = (action: string) => {
    switch (action) {
      case 'video':
        navigate('/video-call');
        break;
      case 'message':
        navigate('/messages');
        break;
      case 'ai':
        navigate('/ai-chatbot');
        break;
      case 'reports':
        navigate('/reports');
        break;
      default:
        break;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {/* Credit Balance */}
        <div className="mb-8">
          <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg shadow-lg p-6 text-white">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm opacity-80">Kalan Kredi</p>
                <p className="text-3xl font-bold">{credits}</p>
              </div>
              <button 
                onClick={() => navigate('/credits')}
                className="px-4 py-2 bg-white text-blue-600 rounded-lg font-medium hover:bg-blue-50"
              >
                Kredi Yükle
              </button>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <QuickActionCard
            icon={<Video className="h-6 w-6" />}
            title="Video Görüşme"
            description="Doktorunuzla görüntülü görüşün"
            onClick={() => handleQuickAction('video')}
          />
          <QuickActionCard
            icon={<MessageSquare className="h-6 w-6" />}
            title="Mesajlaşma"
            description="Mesaj gönderin"
            onClick={() => handleQuickAction('message')}
          />
          <QuickActionCard
            icon={<Activity className="h-6 w-6" />}
            title="AI Ön Tanı"
            description="Semptomlarınızı analiz edin"
            onClick={() => handleQuickAction('ai')}
          />
          <QuickActionCard
            icon={<FileText className="h-6 w-6" />}
            title="Raporlarım"
            description="Tıbbi kayıtlarınızı görüntüleyin"
            onClick={() => handleQuickAction('reports')}
          />
        </div>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Appointments */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Son Randevular</h3>
            {userAppointments.length > 0 ? (
              <div className="space-y-4">
                {userAppointments.slice(0, 3).map((appointment) => (
                  <div key={appointment.id} className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{appointment.doctorName}</p>
                      <p className="text-sm text-gray-500">{appointment.specialty}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">
                        {new Date(appointment.date).toLocaleDateString()}
                      </p>
                      <p className="text-sm text-gray-500">{appointment.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-500 py-4">
                Henüz randevunuz bulunmuyor
              </p>
            )}
            <button
              onClick={() => navigate('/appointments')}
              className="mt-4 w-full text-center text-blue-600 hover:text-blue-700 text-sm font-medium"
            >
              Tüm Randevuları Görüntüle
            </button>
          </div>

          {/* Recent Reports */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold mb-4">Son Raporlar</h3>
            <div className="text-center text-gray-500 py-4">
              Henüz rapor bulunmuyor
            </div>
            <button
              onClick={() => navigate('/reports')}
              className="mt-4 w-full text-center text-blue-600 hover:text-blue-700 text-sm font-medium"
            >
              Tüm Raporları Görüntüle
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const QuickActionCard = ({ 
  icon, 
  title, 
  description, 
  onClick 
}: { 
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
}) => (
  <button 
    className="bg-white p-6 rounded-lg shadow hover:shadow-md transition-shadow"
    onClick={onClick}
  >
    <div className="text-blue-600 mb-3">{icon}</div>
    <h3 className="text-sm font-medium text-gray-900 mb-1">{title}</h3>
    <p className="text-xs text-gray-500">{description}</p>
  </button>
);

export default PatientDashboard;