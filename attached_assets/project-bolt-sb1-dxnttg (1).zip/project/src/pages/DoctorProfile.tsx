import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Star, MapPin, Phone, Mail, Calendar, MessageSquare } from 'lucide-react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';

export default function DoctorProfile() {
  const { doctorId } = useParams();
  const navigate = useNavigate();
  const { users } = useData();
  const { user } = useAuth();

  const doctor = users.find(u => u.id === doctorId && u.role === 'doctor');

  if (!doctor || !doctor.doctorInfo) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="bg-red-50 text-red-600 p-4 rounded-lg">
          Doktor bulunamadı.
        </div>
      </div>
    );
  }

  const handleAction = (type: 'appointment' | 'message') => {
    if (!user) {
      navigate('/login', { state: { from: `/doctors/${doctorId}` } });
      return;
    }

    switch (type) {
      case 'appointment':
        navigate(`/appointments/schedule/${doctorId}`);
        break;
      case 'message':
        navigate(`/messages/new/${doctorId}`);
        break;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-lg p-6">
        {/* Header */}
        <div className="flex items-center space-x-6 mb-8">
          <div className="w-32 h-32 bg-gray-200 rounded-full flex items-center justify-center">
            {doctor.profileImage ? (
              <img
                src={doctor.profileImage}
                alt={doctor.name}
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              <span className="text-3xl font-bold text-gray-400">
                {doctor.name.charAt(0)}
              </span>
            )}
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{doctor.name}</h1>
            <p className="text-lg text-gray-600">{doctor.doctorInfo.specialty}</p>
            <div className="flex items-center mt-2">
              <Star className="w-5 h-5 text-yellow-400 fill-current" />
              <span className="ml-1 font-medium">{doctor.doctorInfo.rating}</span>
              <span className="mx-2 text-gray-300">•</span>
              <span className="text-gray-600">{doctor.doctorInfo.experience} yıl deneyim</span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex space-x-4 mb-8">
          <button
            onClick={() => handleAction('appointment')}
            className="flex-1 flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Calendar className="w-5 h-5 mr-2" />
            Randevu Al
          </button>
          <button
            onClick={() => handleAction('message')}
            className="flex-1 flex items-center justify-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
          >
            <MessageSquare className="w-5 h-5 mr-2" />
            Mesaj Gönder
          </button>
        </div>

        {/* Contact Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="flex items-center text-gray-600">
            <Phone className="w-5 h-5 mr-2" />
            <span>{doctor.phone}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Mail className="w-5 h-5 mr-2" />
            <span>{doctor.email}</span>
          </div>
        </div>

        {/* About */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Hakkında</h2>
          <p className="text-gray-600">
            {doctor.doctorInfo.title} {doctor.name}, {doctor.doctorInfo.experience} yıllık deneyime sahip bir {doctor.doctorInfo.specialty} uzmanıdır.
          </p>
        </div>

        {/* Education */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Eğitim</h2>
          <div className="space-y-4">
            <div>
              <p className="font-medium text-gray-900">İstanbul Üniversitesi Tıp Fakültesi</p>
              <p className="text-gray-600">Tıp Doktoru</p>
            </div>
            <div>
              <p className="font-medium text-gray-900">Ankara Üniversitesi Tıp Fakültesi</p>
              <p className="text-gray-600">{doctor.doctorInfo.specialty} Uzmanlık</p>
            </div>
          </div>
        </div>

        {/* Reviews */}
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Hasta Yorumları</h2>
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center mb-2">
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                <span className="ml-2 text-sm text-gray-600">1 ay önce</span>
              </div>
              <p className="text-gray-600">
                Çok ilgili ve profesyonel bir doktor. Detaylı açıklamaları ve sabırlı yaklaşımı için teşekkür ederim.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}