import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Mail, Lock, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Login = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      await login(formData.email, formData.password);
      
      // Redirect based on user role and email
      if (formData.email === 'admin@test.com') {
        navigate('/admin');
      } else if (formData.email.includes('doctor')) {
        navigate('/doctor/dashboard');
      } else {
        navigate('/dashboard');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Giriş yapılamadı. Lütfen bilgilerinizi kontrol edin.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      {/* ... rest of the component code ... */}

      {/* Test Accounts */}
      <div className="mt-6">
        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-300" />
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-white text-gray-500">Test Hesapları</span>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 gap-3">
          <div className="text-sm text-gray-500">
            <p><strong>Admin:</strong> admin@test.com / test123</p>
            <p><strong>Doktor:</strong> doctor@test.com / test123</p>
            <p><strong>Hasta:</strong> hasta@test.com / test123</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;