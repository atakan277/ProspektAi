import React from 'react';

export default function Terms() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="bg-white rounded-lg shadow-lg p-8">
        <h1 className="text-3xl font-bold mb-6">Kullanıcı Sözleşmesi</h1>
        
        <div className="prose max-w-none">
          <h2 className="text-xl font-semibold mt-8 mb-4">1. Hizmetin Kapsamı</h2>
          <p>
            OnlineSağlık, uzman hekimlerle hastalar arasında iletişimi kolaylaştıran dijital bir platformdur. 
            Platform üzerinden sunulan hizmetler, yüz yüze muayene ve klinik değerlendirmenin yerini tutmaz. 
            Platformumuz, randevu alma sürecini kolaylaştırmak ve uzman hekimlere danışmanlık amacıyla soru 
            sorma imkanı sunmak için tasarlanmıştır.
          </p>

          <h2 className="text-xl font-semibold mt-8 mb-4">2. Kullanım Koşulları</h2>
          <p>
            Platform üzerinden alınan görüş ve öneriler, genel bilgilendirme amaçlıdır ve tıbbi tanı veya 
            tedavi yerine geçmez. Acil durumlarda ve ciddi sağlık sorunlarında en yakın sağlık kuruluşuna 
            başvurulması gerekmektedir.
          </p>

          <h2 className="text-xl font-semibold mt-8 mb-4">3. Sorumluluk Sınırları</h2>
          <p>
            OnlineSağlık, platform üzerinden verilen hizmetlerin doğruluğu, yeterliliği ve güncelliği 
            konusunda garanti vermemektedir. Kullanıcılar, platformu kendi iradeleriyle kullanmakta ve 
            riskleri kabul etmektedir.
          </p>

          <h2 className="text-xl font-semibold mt-8 mb-4">4. Gizlilik ve Veri Güvenliği</h2>
          <p>
            Kullanıcıların kişisel ve sağlık verileri, yürürlükteki mevzuata uygun olarak işlenmekte ve 
            korunmaktadır. Detaylı bilgi için Gizlilik Politikamızı inceleyebilirsiniz.
          </p>

          <h2 className="text-xl font-semibold mt-8 mb-4">5. Ödeme ve İade Koşulları</h2>
          <p>
            Platform üzerinden satın alınan krediler ve hizmetler için iade koşulları, ilgili hizmetin 
            kullanılmamış olması şartıyla geçerlidir. Kullanılan hizmetler için iade yapılmamaktadır.
          </p>

          <h2 className="text-xl font-semibold mt-8 mb-4">6. Fikri Mülkiyet</h2>
          <p>
            Platform üzerindeki tüm içerik ve materyaller OnlineSağlık'ın fikri mülkiyetindedir. 
            Kullanıcılar, bu içerikleri izinsiz kopyalayamaz veya dağıtamaz.
          </p>

          <div className="bg-gray-50 p-4 rounded-lg mt-8">
            <p className="text-sm text-gray-600">
              Bu sözleşmeyi kabul ederek, yukarıda belirtilen tüm koşulları okuduğunuzu ve anladığınızı 
              beyan etmektesiniz. OnlineSağlık, bu sözleşmede değişiklik yapma hakkını saklı tutar.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}