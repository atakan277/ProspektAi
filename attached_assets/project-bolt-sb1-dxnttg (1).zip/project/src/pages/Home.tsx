import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Video, MessageSquare, Brain, Shield, Clock, CreditCard } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Home = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const handleStartClick = () => {
    if (user) {
      navigate('/services');
    } else {
      navigate('/register');
    }
  };

  const handleAIClick = () => {
    if (user) {
      navigate('/ai-chatbot');
    } else {
      navigate('/login', { state: { from: '/ai-chatbot' } });
    }
  };

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                Sağlık Hizmetlerine Anında Erişim
              </h1>
              <p className="text-xl mb-8">
                Uzman doktorlarla görüntülü görüşün, Yapay Zeka destekli ön tanı alın, 
                tıbbi kayıtlarınızı güvenle yönetin.
              </p>
              <div className="space-x-4">
                <button
                  onClick={handleStartClick}
                  className="inline-block px-8 py-3 bg-white text-blue-600 rounded-lg font-semibold hover:bg-gray-100"
                >
                  {user ? 'Hizmetlere Git' : 'Hemen Başlayın'}
                </button>
                <button 
                  onClick={handleAIClick}
                  className="inline-block px-8 py-3 border-2 border-white rounded-lg font-semibold hover:bg-blue-700"
                >
                  Yapay Zeka Tıbbi Asistana Danışın
                </button>
              </div>
            </div>
            <div className="hidden md:block">
              <img 
                src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=2070&q=80" 
                alt="Telemedicine" 
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Özellikler</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Video />}
              title="Video Konsültasyon"
              description="Uzman doktorlarla görüntülü görüşme yapın, sağlık sorunlarınızı evden çözün."
              onClick={() => navigate('/video-call')}
            />
            <FeatureCard 
              icon={<MessageSquare />}
              title="Anlık Mesajlaşma"
              description="Doktorunuzla güvenli bir şekilde mesajlaşın, sorularınıza hızlı yanıt alın."
              onClick={() => navigate('/messages')}
            />
            <FeatureCard 
              icon={<Brain />}
              title="Yapay Zeka Tıbbi Asistan"
              description="Semptomlarınızı değerlendirin, yapay zeka teknolojisiyle ön tanı alın."
              onClick={() => navigate('/ai-chatbot')}
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">
            Sağlığınız İçin İlk Adımı Atın
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Hemen üye olun, kredi satın alın ve uzman doktorlarla görüşmeye başlayın.
          </p>
          <button
            onClick={handleStartClick}
            className="inline-block px-8 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
          >
            {user ? 'Hizmetlere Git' : 'Ücretsiz Üye Olun'}
          </button>
        </div>
      </section>
    </div>
  );
};

const FeatureCard = ({ 
  icon, 
  title, 
  description, 
  onClick 
}: { 
  icon: React.ReactNode;
  title: string;
  description: string;
  onClick: () => void;
}) => (
  <div 
    className="p-6 bg-white rounded-lg shadow-lg border border-gray-100 hover:shadow-xl transition-shadow cursor-pointer"
    onClick={onClick}
  >
    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600 mb-4">
      {icon}
    </div>
    <h3 className="text-xl font-semibold mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
);

export default Home;