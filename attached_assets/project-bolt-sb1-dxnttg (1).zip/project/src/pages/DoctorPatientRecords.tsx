import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Search, User, FileText, Download } from 'lucide-react';

interface PatientRecord {
  id: string;
  patientId: string;
  patientName: string;
  recordType: string;
  date: string;
  description: string;
  fileUrl?: string;
}

const mockRecords: PatientRecord[] = [
  {
    id: 'r1',
    patientId: 'p1',
    patientName: 'Ahmet Yılmaz',
    recordType: 'Muayene Notu',
    date: '2024-03-10',
    description: 'Rutin kontrol muayenesi',
    fileUrl: '#'
  },
  {
    id: 'r2',
    patientId: 'p2',
    patientName: 'Ayşe Kaya',
    recordType: 'Test Sonucu',
    date: '2024-03-08',
    description: 'Kan tahlili sonuçları',
    fileUrl: '#'
  }
];

export default function DoctorPatientRecords() {
  const { user } = useAuth();
  const [records, setRecords] = useState(mockRecords);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredRecords = records.filter(record =>
    record.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    record.recordType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">Hasta Kayıtları</h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Hasta veya kayıt türü ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      <div className="divide-y divide-gray-200">
        {filteredRecords.map((record) => (
          <div key={record.id} className="p-6 hover:bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-gray-500" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-900">
                    {record.patientName}
                  </h3>
                  <div className="flex items-center space-x-4 mt-1">
                    <span className="text-sm text-gray-500">
                      {new Date(record.date).toLocaleDateString()}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {record.recordType}
                    </span>
                  </div>
                  <p className="mt-2 text-sm text-gray-600">{record.description}</p>
                </div>
              </div>

              {record.fileUrl && (
                <button
                  onClick={() => window.open(record.fileUrl, '_blank')}
                  className="flex items-center px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                >
                  <Download className="w-4 h-4 mr-2" />
                  İndir
                </button>
              )}
            </div>
          </div>
        ))}

        {filteredRecords.length === 0 && (
          <div className="p-6 text-center text-gray-500">
            Kayıt bulunamadı.
          </div>
        )}
      </div>
    </div>
  );
}