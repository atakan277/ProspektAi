import React, { createContext, useContext, useState } from 'react';
import type { User } from '../types/user';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: any) => Promise<void>;
  logout: () => void;
  updateProfile: (data: Partial<User>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Test hesapları için sabit şifre
const TEST_PASSWORD = 'test123';

// Initial test users
const initialUsers = [
  {
    id: 'admin1',
    name: 'Admin User',
    email: 'admin@test.com',
    password: TEST_PASSWORD,
    role: 'admin',
    phone: '+90 539 834 7434'
  },
  {
    id: 'doctor1',
    name: 'Dr. Ahmet Yılmaz',
    email: 'doctor@test.com',
    password: TEST_PASSWORD,
    role: 'doctor',
    phone: '+90 539 834 7434',
    doctorInfo: {
      specialty: 'Kardiyoloji',
      title: 'Prof. Dr.',
      experience: 15,
      rating: 4.8,
      status: 'approved'
    }
  },
  {
    id: 'patient1',
    name: 'Test Hasta',
    email: 'hasta@test.com',
    password: TEST_PASSWORD,
    role: 'patient',
    phone: '+90 539 834 7434'
  }
];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const login = async (email: string, password: string) => {
    const foundUser = initialUsers.find(u => u.email === email && password === TEST_PASSWORD);
    if (!foundUser) {
      throw new Error('Geçersiz kullanıcı bilgileri');
    }
    setUser(foundUser);
    localStorage.setItem('user', JSON.stringify(foundUser));
  };

  const register = async (userData: any) => {
    // Simulated registration
    const newUser = {
      id: `user_${Date.now()}`,
      ...userData
    };
    setUser(newUser);
    localStorage.setItem('user', JSON.stringify(newUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const updateProfile = async (data: Partial<User>) => {
    if (!user) return;
    const updatedUser = { ...user, ...data };
    setUser(updatedUser);
    localStorage.setItem('user', JSON.stringify(updatedUser));
  };

  const value = {
    user,
    login,
    register,
    logout,
    updateProfile
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}