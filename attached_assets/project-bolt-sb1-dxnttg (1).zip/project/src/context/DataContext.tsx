import React, { createContext, useContext, useState, useEffect } from 'react';
import type { User } from '../types/user';
import type { Message } from '../types/message';
import type { Appointment } from '../types/appointment';

interface DataContextType {
  users: User[];
  messages: Message[];
  appointments: Appointment[];
  addMessage: (message: Message) => void;
  addAppointment: (appointment: Appointment) => void;
  updateAppointmentStatus: (appointmentId: string, status: Appointment['status']) => void;
  getMessagesForUser: (userId: string) => Message[];
  getAppointmentsForUser: (userId: string) => Appointment[];
}

const DataContext = createContext<DataContextType | undefined>(undefined);

// Initial test users
const initialUsers: User[] = [
  {
    id: 'admin1',
    name: 'Admin User',
    email: 'admin@test.com',
    role: 'admin',
    phone: '+90 555 111 0000'
  },
  {
    id: 'doctor1',
    name: 'Dr. Ahmet Yılmaz',
    email: 'doctor1@test.com',
    role: 'doctor',
    phone: '+90 555 111 2222',
    doctorInfo: {
      specialty: 'Kardiyoloji',
      title: 'Prof. Dr.',
      experience: 15,
      rating: 4.8,
      status: 'approved'
    }
  },
  {
    id: 'doctor2',
    name: 'Dr. Ayşe Kaya',
    email: 'doctor2@test.com',
    role: 'doctor',
    phone: '+90 555 111 3333',
    doctorInfo: {
      specialty: 'Nöroloji',
      title: 'Doç. Dr.',
      experience: 12,
      rating: 4.7,
      status: 'approved'
    }
  }
];

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [users, setUsers] = useState<User[]>(() => {
    const savedUsers = localStorage.getItem('users');
    return savedUsers ? JSON.parse(savedUsers) : initialUsers;
  });

  const [messages, setMessages] = useState<Message[]>(() => {
    const savedMessages = localStorage.getItem('messages');
    return savedMessages ? JSON.parse(savedMessages) : [];
  });

  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    const savedAppointments = localStorage.getItem('appointments');
    return savedAppointments ? JSON.parse(savedAppointments) : [];
  });

  useEffect(() => {
    localStorage.setItem('users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('messages', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('appointments', JSON.stringify(appointments));
  }, [appointments]);

  const addMessage = (message: Message) => {
    setMessages(prev => [...prev, message]);
  };

  const addAppointment = (appointment: Appointment) => {
    setAppointments(prev => [...prev, appointment]);
  };

  const updateAppointmentStatus = (appointmentId: string, status: Appointment['status']) => {
    setAppointments(prev => prev.map(app => 
      app.id === appointmentId ? { ...app, status } : app
    ));
  };

  const getMessagesForUser = (userId: string) => {
    return messages.filter(msg => 
      msg.senderId === userId || msg.receiverId === userId
    ).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  };

  const getAppointmentsForUser = (userId: string) => {
    return appointments.filter(app => 
      app.doctorId === userId || app.patientId === userId
    ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const value = {
    users,
    messages,
    appointments,
    addMessage,
    addAppointment,
    updateAppointmentStatus,
    getMessagesForUser,
    getAppointmentsForUser
  };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}