import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

interface CreditContextType {
  credits: number;
  addCredits: (amount: number) => void;
  spendCredits: (amount: number) => boolean;
  transferCredits: (fromUserId: string, toUserId: string, amount: number, commission?: number) => boolean;
  getCredits: (userId: string) => number;
}

const CreditContext = createContext<CreditContextType | undefined>(undefined);

export function CreditProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [userCredits, setUserCredits] = useState<Record<string, number>>(() => {
    const saved = localStorage.getItem('userCredits');
    return saved ? JSON.parse(saved) : {};
  });

  useEffect(() => {
    localStorage.setItem('userCredits', JSON.stringify(userCredits));
  }, [userCredits]);

  const getCredits = (userId: string): number => {
    return userCredits[userId] || 0;
  };

  const addCredits = (amount: number) => {
    if (!user) return;
    setUserCredits(prev => ({
      ...prev,
      [user.id]: (prev[user.id] || 0) + amount
    }));
  };

  const spendCredits = (amount: number): boolean => {
    if (!user) return false;
    const currentCredits = userCredits[user.id] || 0;
    if (currentCredits < amount) return false;

    setUserCredits(prev => ({
      ...prev,
      [user.id]: currentCredits - amount
    }));
    return true;
  };

  const transferCredits = (fromUserId: string, toUserId: string, amount: number, commission = 0.2): boolean => {
    const fromUserCredits = userCredits[fromUserId] || 0;
    if (fromUserCredits < amount) return false;

    const commissionAmount = Math.floor(amount * commission);
    const transferAmount = amount - commissionAmount;

    setUserCredits(prev => ({
      ...prev,
      [fromUserId]: fromUserCredits - amount,
      [toUserId]: (prev[toUserId] || 0) + transferAmount
    }));

    return true;
  };

  const value = {
    credits: user ? userCredits[user.id] || 0 : 0,
    addCredits,
    spendCredits,
    transferCredits,
    getCredits
  };

  return <CreditContext.Provider value={value}>{children}</CreditContext.Provider>;
}

export function useCredits() {
  const context = useContext(CreditContext);
  if (context === undefined) {
    throw new Error('useCredits must be used within a CreditProvider');
  }
  return context;
}