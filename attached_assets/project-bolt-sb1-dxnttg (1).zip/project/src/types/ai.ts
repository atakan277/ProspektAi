export interface AIMessage {
  id: number;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

export interface DoctorRecommendation {
  doctor: {
    id: string;
    name: string;
    specialty: string;
    title: string;
    experience: number;
    rating: number;
    image: string;
    availableSlots: string[];
  };
  reason: string;
}

export interface AIResponse {
  success: boolean;
  text: string | null;
  error: string | null;
  recommendations: DoctorRecommendation[];
}

export interface ChatState {
  messages: AIMessage[];
  isLoading: boolean;
  error: string | null;
  recommendations: DoctorRecommendation[];
}