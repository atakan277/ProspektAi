export interface Location {
  name: string;
  address: string;
  city: string;
}

export interface Contact {
  phone: string;
  email: string;
}

export interface Appointment {
  id: string;
  title: string;
  doctorName: string;
  specialty: string;
  date: string;
  time: string;
  status: 'upcoming' | 'completed' | 'cancelled';
  location: Location;
  contact: Contact;
}