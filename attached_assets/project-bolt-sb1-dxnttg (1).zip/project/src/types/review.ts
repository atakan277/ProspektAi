export interface Review {
  id: string;
  doctorId: string;
  patientId: string;
  patientName: string;
  rating: number;
  comment: string;
  date: Date;
  verified: boolean;
  appointmentId?: string;
  likes?: number;
  response?: {
    text: string;
    date: Date;
  };
}