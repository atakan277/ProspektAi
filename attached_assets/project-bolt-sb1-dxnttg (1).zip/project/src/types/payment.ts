export interface PaymentPackage {
  id: number;
  credits: number;
  price: number;
  name: string;
}

export interface PaymentRequest {
  amount: number;
  referenceId: string;
  description: string;
  turkishNationalId: string;
}

export interface PaymentResponse {
  success: boolean;
  paymentId?: string;
  paymentPageUrl?: string;
  error?: string;
}