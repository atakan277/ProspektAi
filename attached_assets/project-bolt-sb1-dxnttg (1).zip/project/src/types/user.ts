// Mevcut User interface'ine eklenecek alanlar
export interface User {
  // ... mevcut alanlar ...
  emailVerified: boolean;
  verificationToken?: string;
  verificationTokenExpires?: Date;
}