export interface EmailData {
  email: string;
  token: string;
  expiresAt: string;
}