export interface AdminStats {
  totalDoctors: number;
  pendingApprovals: number;
  totalPatients: number;
  activeAppointments: number;
  totalRevenue?: number;
  totalCredits?: number;
  activeUsers?: number;
  lastMonthGrowth?: {
    doctors: number;
    patients: number;
    revenue: number;
  };
}

export interface AdminAction {
  id: string;
  type: 'approval' | 'rejection' | 'deletion' | 'modification';
  targetId: string;
  targetType: 'doctor' | 'patient';
  reason?: string;
  timestamp: Date;
  adminId: string;
}

export interface SystemLog {
  id: string;
  type: 'info' | 'warning' | 'error';
  message: string;
  timestamp: Date;
  details?: Record<string, any>;
}

export interface AdminNotification {
  id: string;
  type: 'approval_needed' | 'system_alert' | 'user_report';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  priority: 'low' | 'medium' | 'high';
  actionRequired: boolean;
}

export interface UserReport {
  id: string;
  reporterId: string;
  reportedId: string;
  type: 'inappropriate_behavior' | 'fake_account' | 'other';
  description: string;
  timestamp: Date;
  status: 'pending' | 'investigating' | 'resolved' | 'dismissed';
  resolution?: string;
}

export interface AdminSettings {
  autoApproveVerifiedDoctors: boolean;
  requirePhoneVerification: boolean;
  maxLoginAttempts: number;
  sessionTimeout: number;
  maintenanceMode: boolean;
  notificationSettings: {
    emailNotifications: boolean;
    pushNotifications: boolean;
    dailyReports: boolean;
  };
  securitySettings: {
    twoFactorAuth: boolean;
    ipWhitelist: string[];
    passwordPolicy: {
      minLength: number;
      requireSpecialChars: boolean;
      requireNumbers: boolean;
      requireUppercase: boolean;
      expirationDays: number;
    };
  };
}