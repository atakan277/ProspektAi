export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  title: string;
  experience: number;
  rating: number;
  image: string;
  availableSlots: string[];
  location: {
    name: string;
    address: string;
    city: string;
  };
  contact: {
    phone: string;
    email: string;
  };
  education: {
    university: string;
    graduationYear: string;
    specialtyTraining: string;
  };
  languages: string[];
  acceptedInsurances: string[];
  about: string;
}