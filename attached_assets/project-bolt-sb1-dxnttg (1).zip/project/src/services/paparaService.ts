import axios from 'axios';

const PAPARA_API_KEY = 'a36a4757-8988-4c66-bd6e-bb153c1ca1cc';
const PAPARA_API_URL = 'https://sandbox.merchant-api.papara.com';

export interface PaparaPaymentRequest {
  amount: number;
  referenceId: string;
  description: string;
  turkishNationalId: string;
}

export interface PaparaPaymentResponse {
  success: boolean;
  paymentId?: string;
  paymentPageUrl?: string;
  error?: string;
}

export async function createPayment(request: PaparaPaymentRequest): Promise<PaparaPaymentResponse> {
  try {
    const response = await axios.post(`${PAPARA_API_URL}/payments`, {
      amount: request.amount,
      referenceId: request.referenceId,
      description: request.description,
      turkishNationalId: request.turkishNationalId,
      notificationUrl: `${window.location.origin}/api/payment/callback`,
      redirectUrl: `${window.location.origin}/payment/success`,
      currency: 'TRY'
    }, {
      headers: {
        'ApiKey': PAPARA_API_KEY,
        'Content-Type': 'application/json'
      }
    });

    return {
      success: true,
      paymentId: response.data.id,
      paymentPageUrl: response.data.paymentPageUrl
    };
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error('Papara payment error:', error.response?.data || error.message);
      return {
        success: false,
        error: error.response?.data?.message || 'Ödeme işlemi başlatılamadı'
      };
    }
    
    console.error('Papara payment error:', error);
    return {
      success: false,
      error: 'Ödeme işlemi sırasında bir hata oluştu'
    };
  }
}