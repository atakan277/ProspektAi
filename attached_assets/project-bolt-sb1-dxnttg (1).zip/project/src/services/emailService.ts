import type { EmailData } from '../types/email';

export const sendVerificationEmail = async (email: string, verificationToken: string): Promise<boolean> => {
  const verificationLink = `${window.location.origin}/verify-email?token=${verificationToken}`;

  try {
    // Simulated email sending for development
    console.log('Verification email sent to:', email);
    console.log('Verification link:', verificationLink);
    
    // Store verification data in localStorage for development
    const emailData: EmailData = {
      email,
      token: verificationToken,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24 hours
    };
    
    const verificationData = JSON.parse(localStorage.getItem('verificationData') || '[]');
    verificationData.push(emailData);
    localStorage.setItem('verificationData', JSON.stringify(verificationData));

    return true;
  } catch (error) {
    console.error('Failed to send verification email:', error);
    return false;
  }
};