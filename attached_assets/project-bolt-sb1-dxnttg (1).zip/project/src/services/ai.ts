import { GoogleGenerativeAI } from '@google/generative-ai';
import { AIResponse } from '../types/ai';
import { doctors } from '../data/doctors';

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;
const genAI = new GoogleGenerativeAI(API_KEY);

const PROMPT_TEMPLATE = `
Bir tıp uzmanı olarak, aşağıdaki semptomları detaylı şekilde analiz edin ve en uygun uzmanlık alanlarını belirleyin.
Yanıtınızı akademik bir makale formatında, düzgün paragraflar halinde yapılandırın.

Analiz Bölümleri:
1. Semptomların Detaylı Değerlendirilmesi
2. Olası Tanılar ve İlgili Uzmanlık Alanları
3. Risk Faktörleri ve Önemli Noktalar
4. Öneriler ve Sonraki Adımlar

Hasta şikayeti: {prompt}

Lütfen yanıtınızı profesyonel ve detaylı bir şekilde, tıbbi terminolojiyi uygun şekilde kullanarak oluşturun.
Her bölümü ayrı başlıklar altında ele alın ve önemli noktaları vurgulayın.
`;

export async function generateAIResponse(prompt: string): Promise<AIResponse> {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
    
    const result = await model.generateContent(PROMPT_TEMPLATE.replace('{prompt}', prompt));
    const response = result.response.text();
    
    if (!response) {
      throw new Error('AI yanıtı alınamadı');
    }

    // Semptomları analiz et ve ilgili uzmanlık alanlarını belirle
    const specialties = analyzeSymptoms(prompt.toLowerCase() + ' ' + response.toLowerCase());
    
    // İlgili doktorları bul ve sırala
    const recommendations = doctors
      .filter(doctor => specialties.includes(doctor.specialty))
      .sort((a, b) => b.rating - a.rating) // En yüksek puanlı doktorları önce göster
      .slice(0, 3)
      .map(doctor => ({
        doctor,
        reason: generateRecommendationReason(doctor.specialty, prompt, response)
      }));

    return {
      success: true,
      text: formatResponse(response),
      error: null,
      recommendations: recommendations.length > 0 ? recommendations : [{
        doctor: doctors.find(d => d.specialty === 'Dahiliye')!,
        reason: 'Şikayetlerinizin detaylı değerlendirilmesi için öncelikle dahiliye uzmanına başvurmanız önerilir.'
      }]
    };
  } catch (error) {
    console.error('AI Service Error:', error);
    return {
      success: false,
      text: null,
      error: 'Üzgünüm, bir hata oluştu. Lütfen daha sonra tekrar deneyin.',
      recommendations: []
    };
  }
}

function analyzeSymptoms(text: string): string[] {
  const specialtyKeywords: Record<string, string[]> = {
    'Kardiyoloji': ['kalp', 'göğüs ağrısı', 'çarpıntı', 'tansiyon', 'nefes darlığı', 'ritim bozukluğu', 'kalp krizi', 'damar'],
    'Nöroloji': ['baş ağrısı', 'migren', 'baş dönmesi', 'epilepsi', 'felç', 'titreme', 'unutkanlık', 'sara', 'nöbet', 'inme'],
    'Dahiliye': ['ateş', 'halsizlik', 'yorgunluk', 'kilo', 'iştah', 'öksürük', 'grip', 'enfeksiyon'],
    'Dermatoloji': ['cilt', 'döküntü', 'kaşıntı', 'sivilce', 'leke', 'egzama', 'mantar', 'sedef', 'alerji'],
    'Gastroenteroloji': ['mide', 'bulantı', 'kusma', 'ishal', 'kabızlık', 'karın ağrısı', 'reflü', 'ülser', 'bağırsak'],
    'Psikiyatri': ['anksiyete', 'depresyon', 'uyku', 'stres', 'panik atak', 'bunalım', 'fobi', 'takıntı'],
    'Ortopedi': ['eklem', 'kemik', 'kırık', 'bel ağrısı', 'boyun ağrısı', 'kas ağrısı', 'fıtık', 'romatizma'],
    'Göz Hastalıkları': ['görme', 'göz', 'bulanık görme', 'katarakt', 'glokom', 'şaşılık', 'miyop', 'astigmat'],
    'Kulak Burun Boğaz': ['boğaz', 'kulak', 'burun', 'işitme', 'geniz', 'horlama', 'sinüzit', 'bademcik', 'vertigo'],
    'Üroloji': ['idrar', 'böbrek', 'prostat', 'mesane', 'taş', 'cinsel', 'testis'],
    'Endokrinoloji': ['tiroid', 'şeker hastalığı', 'hormon', 'guatr', 'insülin', 'diyabet', 'metabolizma'],
    'Romatoloji': ['romatizma', 'eklem ağrısı', 'artrit', 'lupus', 'fibromiyalji', 'gut'],
    'Göğüs Hastalıkları': ['öksürük', 'astım', 'bronşit', 'akciğer', 'nefes darlığı', 'zatürre', 'tüberküloz', 'koah'],
    'Fizik Tedavi': ['rehabilitasyon', 'fizik tedavi', 'kas güçsüzlüğü', 'felç sonrası', 'spor yaralanması'],
    'Kadın Hastalıkları': ['kadın hastalıkları', 'hamilelik', 'doğum', 'regl', 'adet', 'yumurtalık', 'rahim', 'menopoz']
  };

  const matchedSpecialties = new Set<string>();
  let maxMatches = 0;
  let bestMatch = '';

  Object.entries(specialtyKeywords).forEach(([specialty, keywords]) => {
    let matches = 0;
    keywords.forEach(keyword => {
      if (text.includes(keyword)) {
        matches++;
      }
    });

    if (matches > 0) {
      matchedSpecialties.add(specialty);
      if (matches > maxMatches) {
        maxMatches = matches;
        bestMatch = specialty;
      }
    }
  });

  // En az bir uzmanlık alanı bulunamazsa dahiliyeyi ekle
  if (matchedSpecialties.size === 0) {
    matchedSpecialties.add('Dahiliye');
  }

  // En çok eşleşen uzmanlık alanını ilk sıraya koy
  const result = Array.from(matchedSpecialties);
  if (bestMatch) {
    result.sort((a, b) => a === bestMatch ? -1 : b === bestMatch ? 1 : 0);
  }

  return result;
}

function generateRecommendationReason(specialty: string, symptoms: string, aiResponse: string): string {
  const reasons: Record<string, string> = {
    'Kardiyoloji': 'Kalp ve dolaşım sistemi ile ilgili şikayetlerinizin detaylı değerlendirilmesi için kardiyoloji uzmanı muayenesi önerilir.',
    'Nöroloji': 'Nörolojik bulgularınızın detaylı değerlendirilmesi ve uygun tedavi planı için nöroloji uzmanı muayenesi gereklidir.',
    'Dahiliye': 'Genel sağlık durumunuzun kapsamlı değerlendirilmesi için dahiliye uzmanı muayenesi önerilir.',
    'Dermatoloji': 'Cilt bulgularınızın detaylı incelenmesi ve uygun tedavi için dermatoloji uzmanına başvurmanız önerilir.',
    'Gastroenteroloji': 'Sindirim sistemi şikayetlerinizin detaylı değerlendirilmesi için gastroenteroloji uzmanı muayenesi gereklidir.',
    'Psikiyatri': 'Psikolojik değerlendirme ve uygun tedavi planı için psikiyatri uzmanı ile görüşmeniz önerilir.',
    'Ortopedi': 'Kas-iskelet sistemi şikayetlerinizin detaylı değerlendirilmesi için ortopedi uzmanı muayenesi gereklidir.',
    'Göz Hastalıkları': 'Göz ile ilgili bulgularınızın detaylı değerlendirilmesi için göz hastalıkları uzmanı muayenesi önerilir.',
    'Kulak Burun Boğaz': 'KBB bölgesi şikayetlerinizin detaylı değerlendirilmesi ve tedavisi için KBB uzmanı muayenesi gereklidir.',
    'Üroloji': 'Ürolojik şikayetlerinizin detaylı değerlendirilmesi ve tedavisi için üroloji uzmanı muayenesi önerilir.',
    'Endokrinoloji': 'Hormonal sistem bulgularınızın detaylı değerlendirilmesi için endokrinoloji uzmanı muayenesi gereklidir.',
    'Romatoloji': 'Romatizmal hastalıklar açısından değerlendirme için romatoloji uzmanı muayenesi önerilir.',
    'Göğüs Hastalıkları': 'Solunum sistemi şikayetlerinizin detaylı değerlendirilmesi için göğüs hastalıkları uzmanı muayenesi gereklidir.',
    'Fizik Tedavi': 'Fiziksel rehabilitasyon ve ağrı tedavisi için fizik tedavi uzmanı değerlendirmesi önerilir.',
    'Kadın Hastalıkları': 'Kadın sağlığı ile ilgili şikayetlerinizin değerlendirilmesi için kadın hastalıkları uzmanı muayenesi gereklidir.'
  };

  return reasons[specialty] || `${specialty} uzmanı tarafından değerlendirilmeniz önerilir.`;
}

function formatResponse(text: string): string {
  return text
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0)
    .map(line => {
      if (line.match(/^\d+\./)) {
        return `\n### ${line}\n`;
      }
      if (line.match(/^[A-Z][\w\s]{2,}:/)) {
        return `\n**${line}**\n`;
      }
      if (line.match(/^[-•]/)) {
        return `\n- ${line.substring(1).trim()}\n`;
      }
      return line;
    })
    .join('\n');
}