import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import AdminLayout from './AdminLayout';
import DoctorLayout from './DoctorLayout';
import PatientLayout from './PatientLayout';
import PublicLayout from './PublicLayout';
import PaymentPage from '../pages/payment/PaymentPage';
import PaymentSuccess from '../pages/payment/PaymentSuccess';

export default function MainLayout() {
  const { user } = useAuth();

  // Kullanıcı rolüne göre layout seç
  if (!user) {
    return <PublicLayout />;
  }

  return (
    <Routes>
      <Route path="/payment" element={<PaymentPage />} />
      <Route path="/payment/success" element={<PaymentSuccess />} />
      
      {/* Admin Routes */}
      {user.role === 'admin' && (
        <Route path="/admin/*" element={<AdminLayout />} />
      )}

      {/* Doctor Routes */}
      {user.role === 'doctor' && (
        <Route path="/doctor/*" element={<DoctorLayout />} />
      )}

      {/* Patient Routes */}
      {user.role === 'patient' && (
        <Route path="/*" element={<PatientLayout />} />
      )}

      {/* Default Redirects */}
      {user.role === 'admin' && <Route path="*" element={<Navigate to="/admin/dashboard" replace />} />}
      {user.role === 'doctor' && <Route path="*" element={<Navigate to="/doctor/dashboard" replace />} />}
      {user.role === 'patient' && <Route path="*" element={<Navigate to="/dashboard" replace />} />}
    </Routes>
  );
}