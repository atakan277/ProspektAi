import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import PatientNavbar from '../components/navigation/PatientNavbar';
import Footer from '../components/Footer';
import PatientDashboard from '../pages/patient/Dashboard';
import Doctors from '../pages/Doctors';
import DoctorProfile from '../pages/DoctorProfile';
import Appointments from '../pages/patient/Appointments';
import Messages from '../pages/patient/Messages';
import Reports from '../pages/patient/Reports';
import Profile from '../pages/patient/Profile';
import AIChatbot from '../pages/patient/AIChatbot';
import CreditPurchase from '../pages/patient/CreditPurchase';

export default function PatientLayout() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <PatientNavbar />
      <main className="flex-grow">
        <Routes>
          <Route path="/dashboard" element={<PatientDashboard />} />
          <Route path="/doctors" element={<Doctors />} />
          <Route path="/doctors/:doctorId" element={<DoctorProfile />} />
          <Route path="/appointments/*" element={<Appointments />} />
          <Route path="/messages/*" element={<Messages />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/ai-chatbot" element={<AIChatbot />} />
          <Route path="/credits" element={<CreditPurchase />} />
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}