import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import DoctorNavbar from '../components/navigation/DoctorNavbar';
import DoctorSidebar from '../components/navigation/DoctorSidebar';
import DoctorDashboard from '../pages/doctor/Dashboard';
import DoctorAppointments from '../pages/doctor/Appointments';
import DoctorMessages from '../pages/doctor/Messages';
import DoctorPatients from '../pages/doctor/Patients';
import DoctorSchedule from '../pages/doctor/Schedule';
import DoctorProfile from '../pages/doctor/Profile';
import DoctorSettings from '../pages/doctor/Settings';
import DoctorPending from '../pages/doctor/Pending';
import { useAuth } from '../context/AuthContext';

export default function DoctorLayout() {
  const { user } = useAuth();

  // Doktor onay bekliyor ise sadece pending sayfasına erişebilir
  if (user?.doctorInfo?.status === 'pending') {
    return (
      <Routes>
        <Route path="/pending" element={<DoctorPending />} />
        <Route path="*" element={<Navigate to="/doctor/pending" replace />} />
      </Routes>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <DoctorNavbar />
      <div className="flex">
        <DoctorSidebar />
        <main className="flex-1 p-8">
          <Routes>
            <Route path="dashboard" element={<DoctorDashboard />} />
            <Route path="appointments" element={<DoctorAppointments />} />
            <Route path="messages" element={<DoctorMessages />} />
            <Route path="patients" element={<DoctorPatients />} />
            <Route path="schedule" element={<DoctorSchedule />} />
            <Route path="profile" element={<DoctorProfile />} />
            <Route path="settings" element={<DoctorSettings />} />
            <Route path="" element={<Navigate to="dashboard" replace />} />
            <Route path="*" element={<Navigate to="dashboard" replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}