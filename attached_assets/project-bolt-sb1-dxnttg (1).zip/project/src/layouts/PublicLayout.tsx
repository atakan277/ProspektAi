import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from '../components/navigation/PublicNavbar';
import Footer from '../components/Footer';
import Home from '../pages/Home';
import About from '../pages/About';
import Login from '../pages/Login';
import Register from '../pages/Register';
import Terms from '../pages/Terms';
import DoctorTerms from '../pages/DoctorTerms';
import Doctors from '../pages/Doctors';
import DoctorProfile from '../pages/DoctorProfile';

export default function PublicLayout() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/doctor-terms" element={<DoctorTerms />} />
          <Route path="/doctors" element={<Doctors />} />
          <Route path="/doctors/:doctorId" element={<DoctorProfile />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}