// AppRoutes'a eklenecek route
<Route path="/verify-email" element={<VerifyEmail />} />