import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Activity, Calendar, MessageSquare, Users, Clock, Settings } from 'lucide-react';

const menuItems = [
  { path: '/doctor/dashboard', icon: Activity, label: 'Dashboard' },
  { path: '/doctor/appointments', icon: Calendar, label: 'Randevular' },
  { path: '/doctor/messages', icon: MessageSquare, label: 'Mesajlar' },
  { path: '/doctor/patients', icon: Users, label: 'Hastalarım' },
  { path: '/doctor/schedule', icon: Clock, label: 'Çalışma Saatleri' },
  { path: '/doctor/settings', icon: Settings, label: 'Ayarlar' }
];

export default function DoctorSidebar() {
  const location = useLocation();

  return (
    <div className="w-64 bg-white shadow-sm min-h-screen">
      <nav className="mt-8 px-4">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center px-4 py-3 mb-2 rounded-lg ${
                isActive 
                  ? 'bg-primary-50 text-primary-600' 
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Icon className="h-5 w-5 mr-3" />
              <span className="text-sm font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}