import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Activity, Users, UserCheck, FileText, Settings } from 'lucide-react';

const menuItems = [
  { path: '/admin/dashboard', icon: Activity, label: 'Dashboard' },
  { path: '/admin/users', icon: Users, label: 'Kullanıcılar' },
  { path: '/admin/doctor-approvals', icon: UserCheck, label: 'Doktor Onayları' },
  { path: '/admin/reports', icon: FileText, label: 'Raporlar' },
  { path: '/admin/settings', icon: Settings, label: 'Ayarlar' }
];

export default function AdminSidebar() {
  const location = useLocation();

  return (
    <div className="w-64 bg-white shadow-sm min-h-screen">
      <nav className="mt-8 px-4">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center px-4 py-3 mb-2 rounded-lg ${
                isActive 
                  ? 'bg-blue-50 text-blue-600' 
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Icon className="h-5 w-5 mr-3" />
              <span className="text-sm font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}