import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Heart, User, LogOut } from 'lucide-react';

export default function AdminNavbar() {
  const { user, logout } = useAuth();

  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/admin/dashboard" className="flex items-center">
              <Heart className="h-8 w-8 text-primary-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">OnlineSağlık</span>
              <span className="ml-2 text-sm font-medium text-gray-500">Admin Panel</span>
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              {user?.profileImage ? (
                <img src={user.profileImage} alt="" className="h-8 w-8 rounded-full" />
              ) : (
                <User className="h-8 w-8 text-gray-400" />
              )}
              <span className="ml-2 text-sm font-medium text-gray-900">{user?.name}</span>
            </div>

            <button
              onClick={logout}
              className="p-2 text-gray-400 hover:text-gray-500"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}