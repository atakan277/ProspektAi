import React from 'react';
import { User } from '../../types/user';

interface PendingDoctorsProps {
  users: User[];
}

export default function PendingDoctors({ users }: PendingDoctorsProps) {
  const pendingDoctors = users.filter(u => u.role === 'doctor' && u.doctorInfo?.status === 'pending');

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-4">Onay Bekleyen Doktorlar</h2>
      <div className="space-y-4">
        {pendingDoctors.map((doctor) => (
          <div key={doctor.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium">{doctor.name}</p>
              <p className="text-sm text-gray-600">{doctor.doctorInfo?.specialty}</p>
            </div>
            <button
              onClick={() => {/* Handle approval */}}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              İncele
            </button>
          </div>
        ))}

        {pendingDoctors.length === 0 && (
          <div className="text-center text-gray-500 py-4">
            Onay bekleyen doktor bulunmuyor
          </div>
        )}
      </div>
    </div>
  );
}