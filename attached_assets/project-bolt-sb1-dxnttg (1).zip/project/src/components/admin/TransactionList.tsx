import React from 'react';

interface Transaction {
  id: string;
  type: string;
  amount: number;
  date: Date;
}

interface TransactionListProps {
  transactions: Transaction[];
}

export default function TransactionList({ transactions }: TransactionListProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-xl font-semibold mb-4">Son İşlemler</h2>
      <div className="space-y-4">
        {transactions.slice(0, 5).map((transaction) => (
          <div key={transaction.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium">{transaction.type}</p>
              <p className="text-sm text-gray-600">
                {new Date(transaction.date).toLocaleDateString()}
              </p>
            </div>
            <div className="text-right">
              <p className="font-medium text-green-600">
                +{transaction.amount} ₺
              </p>
              <p className="text-sm text-gray-600">
                İşlem Tutarı
              </p>
            </div>
          </div>
        ))}

        {transactions.length === 0 && (
          <div className="text-center text-gray-500 py-4">
            Henüz işlem bulunmuyor
          </div>
        )}
      </div>
    </div>
  );
}