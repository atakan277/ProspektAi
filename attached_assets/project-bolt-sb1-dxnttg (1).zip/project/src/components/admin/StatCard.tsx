import React from 'react';

interface StatCardProps {
  icon: React.ReactNode;
  title: string;
  value: number | string;
  bgColor: string;
}

export default function StatCard({ icon, title, value, bgColor }: StatCardProps) {
  return (
    <div className={`${bgColor} rounded-lg p-6`}>
      <div className="flex items-center justify-between">
        {icon}
        <span className="text-2xl font-bold">{value}</span>
      </div>
      <p className="mt-2 text-sm text-gray-600">{title}</p>
    </div>
  );
}