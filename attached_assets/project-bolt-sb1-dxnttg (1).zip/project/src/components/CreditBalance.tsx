import React from 'react';
import { Coins } from 'lucide-react';
import { useCredits } from '../context/CreditContext';
import { Link } from 'react-router-dom';

export default function CreditBalance() {
  const { credits } = useCredits();

  return (
    <div className="flex items-center space-x-2">
      <div className="bg-blue-100 rounded-lg px-3 py-1 flex items-center">
        <Coins className="w-4 h-4 text-blue-600 mr-1" />
        <span className="text-blue-600 font-medium">{credits}</span>
      </div>
      <Link
        to="/credits"
        className="text-sm text-blue-600 hover:text-blue-700 font-medium"
      >
        Kredi Yükle
      </Link>
    </div>
  );
}