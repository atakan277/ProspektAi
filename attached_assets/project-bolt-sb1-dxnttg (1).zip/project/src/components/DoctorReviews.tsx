import React, { useState } from 'react';
import { Star, ThumbsUp, MessageSquare, Flag, Check } from 'lucide-react';
import { Review } from '../types/review';
import { useAuth } from '../context/AuthContext';

interface DoctorReviewsProps {
  doctorId: string;
  reviews: Review[];
  averageRating: number;
  totalReviews: number;
  onAddReview?: (review: Partial<Review>) => void;
}

export default function DoctorReviews({
  doctorId,
  reviews,
  averageRating,
  totalReviews,
  onAddReview
}: DoctorReviewsProps) {
  const { user } = useAuth();
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [newReview, setNewReview] = useState({
    rating: 5,
    comment: ''
  });

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (onAddReview && user) {
      onAddReview({
        doctorId,
        patientId: user.id,
        patientName: user.name,
        rating: newReview.rating,
        comment: newReview.comment,
        date: new Date(),
        verified: true
      });
      setShowReviewForm(false);
      setNewReview({ rating: 5, comment: '' });
    }
  };

  const getRatingDistribution = () => {
    const distribution = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    reviews.forEach(review => {
      distribution[review.rating as keyof typeof distribution]++;
    });
    return distribution;
  };

  const distribution = getRatingDistribution();

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      {/* Genel Değerlendirme */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h3 className="text-2xl font-bold text-gray-900">
            {averageRating.toFixed(1)}
          </h3>
          <div className="flex items-center mt-1">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-5 h-5 ${
                  i < Math.round(averageRating)
                    ? 'text-yellow-400 fill-current'
                    : 'text-gray-300'
                }`}
              />
            ))}
            <span className="ml-2 text-sm text-gray-600">
              {totalReviews} değerlendirme
            </span>
          </div>
        </div>

        {user && !showReviewForm && (
          <button
            onClick={() => setShowReviewForm(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Değerlendir
          </button>
        )}
      </div>

      {/* Puan Dağılımı */}
      <div className="space-y-2 mb-8">
        {Object.entries(distribution).reverse().map(([rating, count]) => (
          <div key={rating} className="flex items-center">
            <div className="w-12 text-sm text-gray-600">
              {rating} yıldız
            </div>
            <div className="flex-1 mx-4 h-4 bg-gray-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-yellow-400"
                style={{
                  width: `${(count / totalReviews) * 100}%`
                }}
              />
            </div>
            <div className="w-12 text-sm text-gray-600 text-right">
              {Math.round((count / totalReviews) * 100)}%
            </div>
          </div>
        ))}
      </div>

      {/* Yorum Formu */}
      {showReviewForm && (
        <form onSubmit={handleSubmitReview} className="mb-8 p-4 bg-gray-50 rounded-lg">
          <h4 className="font-medium text-gray-900 mb-4">
            Değerlendirmenizi Yazın
          </h4>
          
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Puanınız
            </label>
            <div className="flex space-x-2">
              {[1, 2, 3, 4, 5].map((rating) => (
                <button
                  key={rating}
                  type="button"
                  onClick={() => setNewReview({ ...newReview, rating })}
                  className="focus:outline-none"
                >
                  <Star
                    className={`w-8 h-8 ${
                      rating <= newReview.rating
                        ? 'text-yellow-400 fill-current'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Yorumunuz
            </label>
            <textarea
              value={newReview.comment}
              onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
              rows={4}
              className="w-full rounded-lg border-gray-300 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Deneyiminizi paylaşın..."
              required
            />
          </div>

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => setShowReviewForm(false)}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              İptal
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Gönder
            </button>
          </div>
        </form>
      )}

      {/* Yorumlar Listesi */}
      <div className="space-y-6">
        {reviews.map((review) => (
          <div key={review.id} className="border-b border-gray-200 pb-6 last:border-0">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center">
                  <span className="font-medium text-gray-900">
                    {review.patientName}
                  </span>
                  {review.verified && (
                    <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                      <Check className="w-3 h-3 mr-1" />
                      Onaylı Hasta
                    </span>
                  )}
                </div>
                <div className="flex items-center mt-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < review.rating
                          ? 'text-yellow-400 fill-current'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                  <span className="ml-2 text-sm text-gray-600">
                    {new Date(review.date).toLocaleDateString()}
                  </span>
                </div>
              </div>
              
              <button className="text-gray-400 hover:text-gray-600">
                <Flag className="w-4 h-4" />
              </button>
            </div>

            <p className="mt-3 text-gray-600">{review.comment}</p>

            {review.response && (
              <div className="mt-4 ml-6 p-4 bg-gray-50 rounded-lg">
                <p className="text-sm font-medium text-gray-900">
                  Doktor yanıtı:
                </p>
                <p className="mt-1 text-sm text-gray-600">
                  {review.response.text}
                </p>
                <p className="mt-2 text-xs text-gray-500">
                  {new Date(review.response.date).toLocaleDateString()}
                </p>
              </div>
            )}

            <div className="mt-4 flex items-center space-x-4">
              <button className="flex items-center text-gray-400 hover:text-gray-600">
                <ThumbsUp className="w-4 h-4 mr-1" />
                <span className="text-sm">{review.likes || 0}</span>
              </button>
              <button className="flex items-center text-gray-400 hover:text-gray-600">
                <MessageSquare className="w-4 h-4 mr-1" />
                <span className="text-sm">Yanıtla</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}