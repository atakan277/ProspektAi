import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Heart } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-b from-gray-900 to-gray-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Heart className="h-6 w-6 text-primary-500" />
              <h3 className="text-xl font-semibold gradient-text">OnlineSağlık</h3>
            </div>
            <p className="text-gray-400">
              Uzman hekimlerle iletişimi kolaylaştıran, güvenilir ve yenilikçi dijital sağlık platformu.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Hızlı Erişim</h3>
            <ul className="space-y-2">
              <li><Link to="/doctors" className="text-gray-400 hover:text-white transition-colors">Uzman Hekimler</Link></li>
              <li><Link to="/services" className="text-gray-400 hover:text-white transition-colors">Sağlık Hizmetleri</Link></li>
              <li><Link to="/about" className="text-gray-400 hover:text-white transition-colors">Kurumsal</Link></li>
              <li><Link to="/contact" className="text-gray-400 hover:text-white transition-colors">İletişim</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Sağlık Hizmetleri</h3>
            <ul className="space-y-2">
              <li><Link to="/video-consultation" className="text-gray-400 hover:text-white transition-colors">Online Görüntülü Görüşme</Link></li>
              <li><Link to="/chat" className="text-gray-400 hover:text-white transition-colors">Uzman Hekim Danışma</Link></li>
              <li><Link to="/ai-diagnosis" className="text-gray-400 hover:text-white transition-colors">Yapay Zeka Tıbbi Asistan</Link></li>
              <li><Link to="/lab-results" className="text-gray-400 hover:text-white transition-colors">E-Sağlık Raporları</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">İletişim</h3>
            <ul className="space-y-3">
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-2 text-primary-500" />
                <span className="text-gray-400">0539 834 7434</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-2 text-primary-500" />
                <span className="text-gray-400">atakanvolkandogan@gmail.com</span>
              </li>
              <li className="flex items-center">
                <MapPin className="h-5 w-5 mr-2 text-primary-500" />
                <span className="text-gray-400">Hatay, Türkiye</span>
              </li>
            </ul>
            <div className="mt-4 p-3 bg-gray-800 rounded-lg">
              <p className="text-sm text-gray-400">
                7/24 Sağlık Danışma Hattı: 0539 834 7434
              </p>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              © {new Date().getFullYear()} OnlineSağlık. Tüm hakları saklıdır.
            </p>
            <div className="flex space-x-4">
              <Link to="/privacy" className="text-sm text-gray-400 hover:text-white transition-colors">
                Gizlilik Politikası
              </Link>
              <Link to="/terms" className="text-sm text-gray-400 hover:text-white transition-colors">
                Kullanım Koşulları
              </Link>
              <Link to="/kvkk" className="text-sm text-gray-400 hover:text-white transition-colors">
                KVKK Aydınlatma Metni
              </Link>
            </div>
          </div>
          <div className="mt-4 text-xs text-gray-500 text-center">
            OnlineSağlık, uzman hekimlerle iletişimi kolaylaştıran bir platformdur. 
            Platform üzerinden sunulan hizmetler tıbbi tanı ve tedavi yerine geçmez. 
            Acil durumlarda lütfen en yakın sağlık kuruluşuna başvurunuz.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;