import React from 'react';
import { Star, MessageSquare, Calendar } from 'lucide-react';
import type { Doctor } from '../data/doctors';
import { useNavigate } from 'react-router-dom';
import { useCredits } from '../context/CreditContext';
import { useAuth } from '../context/AuthContext';

interface DoctorRecommendationProps {
  doctor: Doctor;
  reason: string;
}

const COSTS = {
  appointment: 150,
  message: 50
};

export default function DoctorRecommendation({ doctor, reason }: DoctorRecommendationProps) {
  const navigate = useNavigate();
  const { credits, spendCredits } = useCredits();
  const { user } = useAuth();

  const handleAction = (type: 'appointment' | 'message') => {
    if (!user) {
      alert('Bu işlemi gerçekleştirmek için giriş yapmalısınız.');
      navigate('/login');
      return;
    }

    const cost = COSTS[type];
    if (credits < cost) {
      alert(`Bu işlem için ${cost} krediye ihtiyacınız var. Lütfen kredi yükleyin.`);
      navigate('/credits');
      return;
    }

    const success = spendCredits(cost);
    if (!success) {
      alert('İşlem gerçekleştirilemedi. Lütfen daha sonra tekrar deneyin.');
      return;
    }

    switch (type) {
      case 'appointment':
        navigate(`/appointments/schedule/${doctor.id}`);
        break;
      case 'message':
        navigate(`/messages/new/${doctor.id}`);
        break;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-4">
      <div className="flex items-center space-x-4 mb-4">
        <img
          src={doctor.image}
          alt={doctor.name}
          className="w-16 h-16 rounded-full object-cover"
        />
        <div>
          <h3 className="text-lg font-semibold">{doctor.name}</h3>
          <p className="text-gray-600">{doctor.specialty}</p>
          <div className="flex items-center mt-1">
            <Star className="w-4 h-4 text-yellow-400 fill-current" />
            <span className="ml-1 text-sm text-gray-600">{doctor.rating}</span>
            <span className="mx-2 text-gray-300">•</span>
            <span className="text-sm text-gray-600">{doctor.experience} yıl deneyim</span>
          </div>
        </div>
      </div>

      <div className="mb-4">
        <p className="text-gray-700">{reason}</p>
      </div>

      <div className="border-t pt-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <button
            onClick={() => handleAction('appointment')}
            className="flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Calendar className="w-4 h-4" />
            <span>Randevu Al ({COSTS.appointment})</span>
          </button>
          <button
            onClick={() => handleAction('message')}
            className="flex items-center justify-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Mesaj ({COSTS.message})</span>
          </button>
        </div>
      </div>
    </div>
  );
}