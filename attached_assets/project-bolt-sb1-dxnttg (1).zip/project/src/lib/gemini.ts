import { GoogleGenerativeAI } from '@google/generative-ai';

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;
const genAI = new GoogleGenerativeAI(API_KEY);

const PROMPT_TEMPLATE = `
Bir tıp uzmanı olarak, aşağıdaki semptomları değerlendirin ve detaylı bir analiz yapın.
Yanıtınızı akademik bir makale formatında, düzgün paragraflar halinde yapılandırın.

Analiz Bölümleri:
1. Semptomların Detaylı Değerlendirilmesi
2. Olası Tanılar ve Nedenleri
3. Risk Faktörleri ve Önemli Noktalar
4. Öneriler ve Sonraki Adımlar

Hasta şikayeti: {prompt}

Lütfen yanıtınızı profesyonel ve detaylı bir şekilde, tıbbi terminolojiyi uygun şekilde kullanarak oluşturun.
Her bölümü ayrı başlıklar altında ele alın ve önemli noktaları vurgulayın.
`;

export interface AIResponse {
  text: string | null;
  error: string | null;
  recommendations: Array<{
    doctor: {
      id: string;
      name: string;
      specialty: string;
      rating: number;
    };
    reason: string;
  }>;
  success: boolean;
}

export async function getAIResponse(prompt: string): Promise<AIResponse> {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-pro' });
    
    const result = await model.generateContent(PROMPT_TEMPLATE.replace('{prompt}', prompt));
    const response = result.response;
    const text = response.text();
    
    if (!text) {
      throw new Error('AI yanıtı alınamadı');
    }

    // Basit doktor önerileri oluştur
    const recommendations = [
      {
        doctor: {
          id: 'd1',
          name: 'Dr. Ahmet Yılmaz',
          specialty: 'Dahiliye',
          rating: 4.8
        },
        reason: 'Genel değerlendirme için dahiliye uzmanına başvurmanız önerilir.'
      }
    ];

    return {
      success: true,
      text,
      error: null,
      recommendations
    };
  } catch (error) {
    console.error('AI Service Error:', error);
    return {
      success: false,
      text: null,
      error: error instanceof Error ? error.message : 'Bilinmeyen bir hata oluştu',
      recommendations: []
    };
  }
}