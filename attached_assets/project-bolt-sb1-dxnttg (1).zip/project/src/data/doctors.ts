import { Doctor } from '../types/doctor';
import { specialties } from './specialties';

// Her uzmanlık dalı için örnek doktor oluştur
export const doctors: Doctor[] = specialties.map((specialty, index) => ({
  id: `d${index + 1}`,
  name: generateDoctorName(),
  specialty: specialty,
  title: generateTitle(),
  experience: Math.floor(Math.random() * 20) + 5, // 5-25 yıl arası deneyim
  rating: Number((4 + Math.random()).toFixed(1)), // 4.0-5.0 arası puan
  image: `https://images.unsplash.com/photo-${index % 2 === 0 ? '1612349317150-e413f6a5b16d' : '1594824476967-48c8b964273f'}?w=200`,
  availableSlots: generateTimeSlots(),
  location: {
    name: 'Özel Muayenehane',
    address: `${specialty} Kliniği, No: ${Math.floor(Math.random() * 100) + 1}`,
    city: 'İstanbul'
  },
  contact: {
    phone: generatePhoneNumber(),
    email: generateEmail(specialty)
  },
  education: {
    university: 'İstanbul Üniversitesi',
    graduationYear: (2024 - (Math.floor(Math.random() * 20) + 5)).toString(),
    specialtyTraining: 'Ankara Üniversitesi'
  },
  languages: ['Türkçe', 'İngilizce'],
  acceptedInsurances: ['SGK', 'Özel Sigortalar'],
  about: `${specialty} alanında uzman hekim. ${Math.floor(Math.random() * 20) + 5} yıllık deneyim.`
}));

// Yardımcı fonksiyonlar
function generateDoctorName(): string {
  const names = [
    'Dr. Ahmet Yılmaz', 'Dr. Ayşe Kaya', 'Dr. Mehmet Demir', 'Dr. Zeynep Arslan',
    'Dr. Can Öztürk', 'Dr. Selin Yıldız', 'Dr. Emre Kılıç', 'Dr. Deniz Şahin',
    'Dr. Berna Aydın', 'Dr. Kemal Özkan', 'Dr. Elif Yalçın', 'Dr. Murat Akar',
    'Dr. Canan Yücel', 'Dr. Serkan Demir', 'Dr. Aylin Çelik', 'Dr. Burak Kaya',
    'Dr. Esra Yılmaz', 'Dr. Onur Aksoy', 'Dr. Gül Demir', 'Dr. Tolga Şahin'
  ];
  return names[Math.floor(Math.random() * names.length)];
}

function generateTitle(): string {
  const titles = ['Prof. Dr.', 'Doç. Dr.', 'Uzm. Dr.', 'Op. Dr.'];
  return titles[Math.floor(Math.random() * titles.length)];
}

function generateTimeSlots(): string[] {
  const slots = ['09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '14:00', '14:30', '15:00', '15:30', '16:00'];
  const numSlots = Math.floor(Math.random() * 4) + 3; // 3-6 slot arası
  const selectedSlots = [];
  for (let i = 0; i < numSlots; i++) {
    const randomSlot = slots[Math.floor(Math.random() * slots.length)];
    if (!selectedSlots.includes(randomSlot)) {
      selectedSlots.push(randomSlot);
    }
  }
  return selectedSlots.sort();
}

function generatePhoneNumber(): string {
  return `+90 (${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}) ${Math.floor(Math.random() * 1000).toString().padStart(3, '0')} ${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`;
}

function generateEmail(specialty: string): string {
  const domain = 'onlinesaglik.com';
  return `dr.${specialty.toLowerCase().replace(/[^a-z0-9]/g, '')}@${domain}`;
}