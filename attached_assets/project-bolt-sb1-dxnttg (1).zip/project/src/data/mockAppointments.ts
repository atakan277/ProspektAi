import { Appointment } from '../types/appointment';

export const mockAppointments: Appointment[] = [
  {
    id: '1',
    title: 'Dr.',
    doctorName: 'Ahmet Yılmaz',
    specialty: 'Kardiyoloji',
    date: '2024-03-15',
    time: '14:30',
    status: 'upcoming',
    location: {
      name: 'Özel Muayenehane',
      address: 'Bağdat Caddesi No: 123',
      city: 'İstanbul, Kadıköy'
    },
    contact: {
      phone: '+90 (532) 555 0123',
      email: 'dr.ahmet@onlinesaglik.com'
    }
  },
  {
    id: '2',
    title: 'Dr.',
    doctorName: 'Ayşe Kaya',
    specialty: 'Nöroloji',
    date: '2024-03-18',
    time: '10:00',
    status: 'upcoming',
    location: {
      name: 'Medikal Center',
      address: 'Nişantaşı Mah. 123. Sok. No: 45',
      city: 'İstanbul, Şişli'
    },
    contact: {
      phone: '+90 (532) 555 0124',
      email: 'dr.ayse@onlinesaglik.com'
    }
  },
  {
    id: '3',
    title: 'Dr.',
    doctorName: 'Mehmet Demir',
    specialty: 'Dahiliye',
    date: '2024-03-10',
    time: '09:30',
    status: 'completed',
    location: {
      name: 'Sağlık Polikliniği',
      address: 'Atatürk Cad. No: 78',
      city: 'İstanbul, Beşiktaş'
    },
    contact: {
      phone: '+90 (532) 555 0125',
      email: 'dr.mehmet@onlinesaglik.com'
    }
  }
];