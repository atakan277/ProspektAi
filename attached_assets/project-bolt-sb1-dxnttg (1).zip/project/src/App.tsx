import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { CreditProvider } from './context/CreditContext';
import { DataProvider } from './context/DataContext';
import MainLayout from './layouts/MainLayout';
import PaymentPage from './pages/payment/PaymentPage';
import PaymentSuccess from './pages/payment/PaymentSuccess';

const App = () => {
  return (
    <DataProvider>
      <AuthProvider>
        <CreditProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/payment" element={<PaymentPage />} />
              <Route path="/payment/success" element={<PaymentSuccess />} />
              <Route path="/*" element={<MainLayout />} />
            </Routes>
          </BrowserRouter>
        </CreditProvider>
      </AuthProvider>
    </DataProvider>
  );
};

export default App;